import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { enum: ["investor", "sourcer", "admin"] }).notNull().default("investor"),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  preferences: jsonb("preferences").$type<{
    locations?: string[];
    budget?: { min: number; max: number };
    strategies?: string[];
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Property deals table
export const deals = pgTable("deals", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  location: varchar("location", { length: 255 }).notNull(),
  address: text("address"),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  monthlyRent: decimal("monthly_rent", { precision: 10, scale: 2 }),
  refurbCost: decimal("refurb_cost", { precision: 10, scale: 2 }),
  marketValue: decimal("market_value", { precision: 12, scale: 2 }),
  bedrooms: integer("bedrooms"),
  bathrooms: integer("bathrooms"),
  squareFeet: integer("square_feet"),
  propertyType: varchar("property_type", { length: 100 }),
  strategy: varchar("strategy", { enum: ["buy-to-let", "brrr", "bmv", "commercial"] }).notNull(),
  status: varchar("status", { enum: ["draft", "pending", "approved", "rejected", "sold"] }).notNull().default("pending"),
  images: jsonb("images").$type<string[]>(),
  documents: jsonb("documents").$type<{ name: string; url: string }[]>(),
  analysis: jsonb("analysis").$type<{
    roi?: number;
    grossYield?: number;
    netYield?: number;
    cashFlow?: number;
    totalReturn?: number;
  }>(),
  sourcerId: varchar("sourcer_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Messages table for investor-sourcer communication
export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  senderId: varchar("sender_id").notNull(),
  receiverId: varchar("receiver_id").notNull(),
  dealId: uuid("deal_id"),
  subject: varchar("subject", { length: 255 }),
  content: text("content").notNull(),
  attachments: jsonb("attachments").$type<{ name: string; url: string }[]>(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Partners table
export const partners = pgTable("partners", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { enum: ["agent", "contractor", "landlord", "solicitor", "surveyor"] }).notNull(),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  location: varchar("location", { length: 255 }),
  description: text("description"),
  website: varchar("website", { length: 255 }),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Testimonials table
export const testimonials = pgTable("testimonials", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  strategy: varchar("strategy", { length: 100 }),
  location: varchar("location", { length: 255 }),
  approved: boolean("approved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Blog posts table
export const blogPosts = pgTable("blog_posts", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  authorId: varchar("author_id").notNull(),
  category: varchar("category", { length: 100 }),
  tags: jsonb("tags").$type<string[]>(),
  published: boolean("published").default(false),
  featuredImage: varchar("featured_image", { length: 500 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Deal interests (investors interested in deals)
export const dealInterests = pgTable("deal_interests", {
  id: uuid("id").primaryKey().defaultRandom(),
  dealId: uuid("deal_id").notNull(),
  investorId: varchar("investor_id").notNull(),
  status: varchar("status", { enum: ["interested", "viewing", "offer_made", "withdrawn"] }).default("interested"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  deals: many(deals),
  sentMessages: many(messages),
  testimonials: many(testimonials),
  blogPosts: many(blogPosts),
  dealInterests: many(dealInterests),
}));

export const dealsRelations = relations(deals, ({ one, many }) => ({
  sourcer: one(users, {
    fields: [deals.sourcerId],
    references: [users.id],
  }),
  messages: many(messages),
  interests: many(dealInterests),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
  }),
  deal: one(deals, {
    fields: [messages.dealId],
    references: [deals.id],
  }),
}));

export const testimonialsRelations = relations(testimonials, ({ one }) => ({
  user: one(users, {
    fields: [testimonials.userId],
    references: [users.id],
  }),
}));

export const blogPostsRelations = relations(blogPosts, ({ one }) => ({
  author: one(users, {
    fields: [blogPosts.authorId],
    references: [users.id],
  }),
}));

export const dealInterestsRelations = relations(dealInterests, ({ one }) => ({
  deal: one(deals, {
    fields: [dealInterests.dealId],
    references: [deals.id],
  }),
  investor: one(users, {
    fields: [dealInterests.investorId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDealSchema = createInsertSchema(deals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertPartnerSchema = createInsertSchema(partners).omit({
  id: true,
  createdAt: true,
});

export const insertTestimonialSchema = createInsertSchema(testimonials).omit({
  id: true,
  createdAt: true,
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDealInterestSchema = createInsertSchema(dealInterests).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Deal = typeof deals.$inferSelect;
export type InsertDeal = z.infer<typeof insertDealSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Partner = typeof partners.$inferSelect;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type DealInterest = typeof dealInterests.$inferSelect;
export type InsertDealInterest = z.infer<typeof insertDealInterestSchema>;
