import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import DealCard from "@/components/deal-card";
import { BarChart3, Search, MessageSquare, TrendingUp, ArrowRight, Check, Clock } from "lucide-react";
import type { Deal, DealInterest, User } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();

  const { data: recentDeals = [] } = useQuery<Deal[]>({
    queryKey: ["/api/deals?status=approved&limit=6"],
  });

  const { data: myInterests = [] } = useQuery<(DealInterest & { deal: Deal })[]>({
    queryKey: ["/api/my-interests"],
    enabled: user?.role === "investor",
  });

  const { data: myDeals = [] } = useQuery<Deal[]>({
    queryKey: ["/api/my-deals"],
    enabled: user?.role === "sourcer",
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Welcome back, {user?.firstName}!
          </h1>
          <p className="text-slate-600">
            {user?.role === "investor" 
              ? "Discover new investment opportunities and manage your portfolio"
              : "Manage your property listings and connect with investors"
            }
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">
                      {user?.role === "investor" ? "Portfolio Value" : "Active Listings"}
                    </span>
                    <BarChart3 className="h-4 w-4 text-slate-400" />
                  </div>
                  <div className="text-2xl font-bold text-slate-900">
                    {user?.role === "investor" ? "£485,000" : myDeals.length}
                  </div>
                  <div className="text-sm text-secondary">
                    {user?.role === "investor" ? "+12.5% this year" : "properties listed"}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">
                      {user?.role === "investor" ? "Monthly Income" : "Total Views"}
                    </span>
                    <TrendingUp className="h-4 w-4 text-slate-400" />
                  </div>
                  <div className="text-2xl font-bold text-slate-900">
                    {user?.role === "investor" ? "£3,240" : "1,247"}
                  </div>
                  <div className="text-sm text-secondary">
                    {user?.role === "investor" ? "+8.2% vs last month" : "this month"}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">
                      {user?.role === "investor" ? "Avg. Yield" : "Conversion Rate"}
                    </span>
                    <BarChart3 className="h-4 w-4 text-slate-400" />
                  </div>
                  <div className="text-2xl font-bold text-slate-900">
                    {user?.role === "investor" ? "8.7%" : "24%"}
                  </div>
                  <div className="text-sm text-secondary">
                    {user?.role === "investor" ? "Above market avg" : "of inquiries"}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {user?.role === "investor" ? (
                    myInterests.slice(0, 3).map((interest) => (
                      <div key={interest.id} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-secondary bg-opacity-10 rounded-lg flex items-center justify-center mr-3">
                            {interest.status === "interested" ? <Clock className="text-warning h-5 w-5" /> : <Check className="text-secondary h-5 w-5" />}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{interest.deal?.title}</div>
                            <div className="text-sm text-slate-500">
                              {interest.status === "interested" ? "Expressed interest" : "Status updated"} • {new Date(interest.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        <Badge variant={interest.status === "interested" ? "secondary" : "default"}>
                          {interest.status}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    myDeals.slice(0, 3).map((deal) => (
                      <div key={deal.id} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mr-3">
                            {deal.status === "approved" ? <Check className="text-secondary h-5 w-5" /> : <Clock className="text-warning h-5 w-5" />}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{deal.title}</div>
                            <div className="text-sm text-slate-500">
                              Listed • {new Date(deal.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        <Badge variant={deal.status === "approved" ? "default" : "secondary"}>
                          {deal.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Recent Deals */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-900">
                  {user?.role === "investor" ? "New Opportunities" : "Market Activity"}
                </h2>
                <Button variant="outline">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {recentDeals.slice(0, 4).map((deal) => (
                  <DealCard key={deal.id} deal={deal} />
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  {user?.role === "investor" ? (
                    <>
                      <Button className="w-full justify-start" size="sm">
                        <Search className="mr-2 h-4 w-4" />
                        Browse New Deals
                        <Badge variant="secondary" className="ml-auto">42</Badge>
                      </Button>
                      <Button variant="outline" className="w-full justify-start" size="sm">
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Portfolio Analytics
                      </Button>
                      <Button variant="outline" className="w-full justify-start" size="sm">
                        <MessageSquare className="mr-2 h-4 w-4" />
                        Messages
                        <Badge variant="destructive" className="ml-auto">3</Badge>
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button className="w-full justify-start" size="sm">
                        <TrendingUp className="mr-2 h-4 w-4" />
                        Submit New Deal
                      </Button>
                      <Button variant="outline" className="w-full justify-start" size="sm">
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Performance Analytics
                      </Button>
                      <Button variant="outline" className="w-full justify-start" size="sm">
                        <MessageSquare className="mr-2 h-4 w-4" />
                        Investor Messages
                        <Badge variant="destructive" className="ml-auto">5</Badge>
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Market Insights */}
            <Card className="bg-gradient-to-r from-secondary to-green-600 text-white">
              <CardContent className="p-6">
                <h4 className="font-semibold mb-2">Market Insight</h4>
                <p className="text-sm text-green-100 mb-4">
                  Manchester yields up 0.3% this quarter. Great time to invest in the North West.
                </p>
                <Button variant="outline" size="sm" className="border-white/30 text-white hover:bg-white/10">
                  Read Full Report
                </Button>
              </CardContent>
            </Card>

            {/* Investment Tips */}
            <Card>
              <CardContent className="p-6">
                <h4 className="font-semibold text-slate-900 mb-4">Investment Tips</h4>
                <div className="space-y-3 text-sm">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h5 className="font-medium text-slate-900 mb-1">BRRR Strategy Focus</h5>
                    <p className="text-slate-600">Look for properties 20-25% below market value for optimal refinancing potential.</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h5 className="font-medium text-slate-900 mb-1">Yield Optimization</h5>
                    <p className="text-slate-600">Target areas with strong rental demand and upcoming regeneration projects.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
