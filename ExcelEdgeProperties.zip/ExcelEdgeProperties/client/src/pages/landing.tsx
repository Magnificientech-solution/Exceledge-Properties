import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import DealCard from "@/components/deal-card";
import AuthModal from "@/components/auth-modal";
import { Building2, Calculator, Shield, MessageSquare, CreditCard, BarChart3, GraduationCap, Star, ArrowRight, Lock, Rocket, Handshake } from "lucide-react";
import { Link } from "wouter";
import type { Deal, Testimonial, User } from "@shared/schema";

export default function Landing() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<"investor" | "sourcer">("investor");

  const { data: featuredDeals = [] } = useQuery<Deal[]>({
    queryKey: ["/api/deals?status=approved&limit=3"],
  });

  const { data: testimonials = [] } = useQuery<(Testimonial & { user: User })[]>({
    queryKey: ["/api/testimonials"],
  });

  const handleGetStarted = (role: "investor" | "sourcer") => {
    setAuthMode(role);
    setShowAuthModal(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(225,40%,96%)] via-white to-[hsl(225,30%,94%)]">
      <Navigation />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary via-[hsl(225,80%,45%)] to-[hsl(225,85%,40%)] text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[hsl(225,90%,25%)]/30 via-transparent to-[hsl(225,90%,25%)]/30"></div>
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.08'%3E%3Ccircle cx='7' cy='7' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")"
        }}></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
              Professional Property Investment <br />
              <span className="bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">Made Simple</span>
            </h1>
            <p className="text-xl md:text-2xl mb-12 text-blue-50 max-w-4xl mx-auto leading-relaxed">
              Connect with verified property sourcers, analyze deals with precision, and build your Buy-to-Let portfolio across the UK and Nigeria with world-class analytics
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-blue-50 hover:shadow-xl px-10 py-5 text-xl font-semibold shadow-2xl transition-all duration-300 transform hover:scale-105 rounded-xl"
                onClick={() => handleGetStarted("investor")}
              >
                <BarChart3 className="mr-3 h-6 w-6" />
                Start as Investor
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-3 border-white/80 bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-primary px-10 py-5 text-xl font-semibold transition-all duration-300 transform hover:scale-105 rounded-xl"
                onClick={() => handleGetStarted("sourcer")}
              >
                <Building2 className="mr-3 h-6 w-6" />
                Join as Sourcer
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold mb-2">£2.4M+</div>
                <div className="text-blue-100 text-lg">Deals Sourced</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold mb-2">500+</div>
                <div className="text-blue-100 text-lg">Active Investors</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold mb-2">8.2%</div>
                <div className="text-blue-100 text-lg">Average Yield</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Deals */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Featured Investment Opportunities</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">Discover pre-analyzed deals with detailed ROI calculations and comprehensive due diligence reports from verified property sourcers</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {featuredDeals.slice(0, 3).map((deal) => (
              <DealCard key={deal.id} deal={deal} />
            ))}
          </div>

          <div className="text-center">
            <Link href="/deals">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 px-10 py-5 text-xl font-semibold shadow-lg transition-all duration-300 rounded-xl">
                Browse All Deals
                <ArrowRight className="ml-3 h-6 w-6" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Platform Features */}
      <section className="py-24 bg-gradient-to-br from-[hsl(225,50%,96%)] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Why Choose Excel Edge Properties?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">Comprehensive tools and verified partnerships for successful property investment</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-blue-100">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-blue-600 rounded-2xl flex items-center justify-center mb-6">
                  <Calculator className="text-white h-8 w-8" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Advanced Deal Analysis</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">Automated ROI calculations, yield analysis, and cash flow projections with detailed comparables and market data.</p>
                <ul className="text-sm text-muted-foreground space-y-3">
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Real-time ROI calculations</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Market value assessments</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Cash flow projections</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-blue-100">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center mb-6">
                  <Shield className="text-white h-8 w-8" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Verified Sourcers</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">Work only with pre-vetted, experienced property sourcers with proven track records and transparent fee structures.</p>
                <ul className="text-sm text-muted-foreground space-y-3">
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Background verified</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Portfolio reviewed</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Client testimonials</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-blue-100">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-primary rounded-2xl flex items-center justify-center mb-6">
                  <MessageSquare className="text-white h-8 w-8" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Direct Communication</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">Built-in messaging system for seamless communication between investors and sourcers throughout the deal process.</p>
                <ul className="text-sm text-muted-foreground space-y-3">
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Deal-specific messaging</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Document sharing</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Progress tracking</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-blue-100">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6">
                  <CreditCard className="text-white h-8 w-8" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Secure Payments</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">Integrated payment processing for sourcing fees, deposits, and transactions with full transparency and security.</p>
                <ul className="text-sm text-muted-foreground space-y-3">
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Stripe integration</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Escrow services</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Payment tracking</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-blue-100">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                  <GraduationCap className="text-white h-8 w-8" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Educational Resources</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">Comprehensive guides, market insights, and educational content to help you make informed investment decisions.</p>
                <ul className="text-sm text-muted-foreground space-y-3">
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Investment guides</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Market analysis</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Legal resources</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-blue-100">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mb-6">
                  <Handshake className="text-white h-8 w-8" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Partner Network</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">Access to our vetted network of solicitors, surveyors, contractors, and other property professionals.</p>
                <ul className="text-sm text-muted-foreground space-y-3">
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Legal services</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Property surveys</li>
                  <li className="flex items-center"><span className="text-primary mr-3 font-bold">✓</span>Renovation services</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">What Our Investors Say</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">Real testimonials from successful property investors using our platform</p>
          </div>

          {testimonials.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.slice(0, 3).map((testimonial) => (
                <Card key={testimonial.id} className="p-8 hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-blue-50 to-white border-blue-100">
                  <CardContent className="p-0">
                    <div className="flex items-center mb-6">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-muted-foreground mb-6 leading-relaxed italic">"{testimonial.content}"</p>
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                        {testimonial.user.firstName?.[0]}{testimonial.user.lastName?.[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">{testimonial.user.firstName} {testimonial.user.lastName}</div>
                        <div className="text-sm text-muted-foreground">Property Investor</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center">
              <p className="text-muted-foreground">No testimonials available yet.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-primary to-blue-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Start Your Property Investment Journey?</h2>
          <p className="text-xl mb-12 text-blue-100 leading-relaxed">Join thousands of successful investors and property sourcers on our platform</p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-blue-50 hover:shadow-xl px-10 py-5 text-xl font-semibold shadow-2xl transition-all duration-300 transform hover:scale-105 rounded-xl"
              onClick={() => handleGetStarted("investor")}
            >
              <Rocket className="mr-3 h-6 w-6" />
              Get Started Today
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-3 border-white/80 bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-primary px-10 py-5 text-xl font-semibold transition-all duration-300 transform hover:scale-105 rounded-xl"
              onClick={() => handleGetStarted("sourcer")}
            >
              <Building2 className="mr-3 h-6 w-6" />
              Become a Sourcer
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">Excel Edge Properties</h3>
              <p className="text-blue-100 mb-6 leading-relaxed">Professional property investment platform connecting investors with verified sourcers across the UK and Nigeria.</p>
              <div className="flex space-x-4">
                <Badge className="bg-primary text-white">Trusted Platform</Badge>
                <Badge className="bg-blue-600 text-white">Verified Sourcers</Badge>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-blue-100">
                <li><a href="#" className="hover:text-white transition-colors">Browse Deals</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Submit Property</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Find Partners</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Resources</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-blue-100">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-blue-800 mt-12 pt-8 text-center">
            <p className="text-blue-100">&copy; 2025 Excel Edge Properties. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
      />
    </div>
  );
}