import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import { BookOpen, Search, Calendar, User, ArrowRight, TrendingUp, Target, Home } from "lucide-react";
import type { BlogPost, User as UserType } from "@shared/schema";

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: blogPosts = [], isLoading } = useQuery<(BlogPost & { author: UserType })[]>({
    queryKey: ["/api/blog"],
  });

  const filteredPosts = blogPosts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.excerpt?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const featuredPost = filteredPosts[0];
  const regularPosts = filteredPosts.slice(1);

  const categories = [
    { name: "BRRR Strategy", count: 12, icon: TrendingUp },
    { name: "Buy-to-Let", count: 8, icon: Home },
    { name: "Market Analysis", count: 15, icon: Target },
    { name: "Investment Tips", count: 10, icon: BookOpen },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">BRRR Education Hub</h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Master property investment strategies with expert insights, market analysis, and proven techniques for building wealth through real estate.
          </p>
        </div>

        {/* Search and Categories */}
        <div className="mb-12">
          <div className="max-w-md mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Categories */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            {categories.map((category) => (
              <Card key={category.name} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <category.icon className="mx-auto h-8 w-8 text-primary mb-3" />
                  <h3 className="font-semibold text-slate-900 mb-1">{category.name}</h3>
                  <p className="text-sm text-slate-500">{category.count} articles</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-48 bg-slate-200" />
                <CardContent className="p-6">
                  <div className="h-4 bg-slate-200 rounded mb-2" />
                  <div className="h-4 bg-slate-200 rounded w-2/3 mb-4" />
                  <div className="h-20 bg-slate-200 rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredPosts.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <BookOpen className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">No articles found</h3>
              <p className="text-slate-500 mb-4">
                {searchTerm ? "Try adjusting your search terms." : "Check back soon for new content."}
              </p>
              {searchTerm && (
                <Button variant="outline" onClick={() => setSearchTerm("")}>
                  Clear Search
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-12">
            {/* Featured Article */}
            {featuredPost && (
              <div>
                <h2 className="text-2xl font-bold text-slate-900 mb-6">Featured Article</h2>
                <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="md:flex">
                    {featuredPost.featuredImage && (
                      <div className="md:w-1/2">
                        <img
                          src={featuredPost.featuredImage}
                          alt={featuredPost.title}
                          className="w-full h-64 md:h-full object-cover"
                        />
                      </div>
                    )}
                    <div className={`p-8 ${featuredPost.featuredImage ? 'md:w-1/2' : 'w-full'}`}>
                      <div className="flex items-center gap-2 mb-4">
                        <Badge variant="secondary">{featuredPost.category || "Investment"}</Badge>
                        <span className="text-sm text-slate-500">Featured</span>
                      </div>
                      <h3 className="text-2xl font-bold text-slate-900 mb-4">{featuredPost.title}</h3>
                      <p className="text-slate-600 mb-6 leading-relaxed">
                        {featuredPost.excerpt || "Learn the essential strategies for successful property investment."}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-slate-500">
                          <User className="mr-1 h-4 w-4" />
                          <span className="mr-4">
                            {featuredPost.author?.firstName} {featuredPost.author?.lastName}
                          </span>
                          <Calendar className="mr-1 h-4 w-4" />
                          <span>{new Date(featuredPost.createdAt).toLocaleDateString()}</span>
                        </div>
                        <Button>
                          Read More
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            )}

            {/* Regular Articles Grid */}
            {regularPosts.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-slate-900 mb-6">Latest Articles</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {regularPosts.map((post) => (
                    <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      {post.featuredImage && (
                        <div className="h-48 bg-slate-200">
                          <img
                            src={post.featuredImage}
                            alt={post.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <CardContent className="p-6">
                        <div className="flex items-center gap-2 mb-3">
                          {post.category && (
                            <Badge variant="outline">{post.category}</Badge>
                          )}
                          {post.tags && post.tags.slice(0, 2).map((tag) => (
                            <Badge key={tag} variant="secondary">{tag}</Badge>
                          ))}
                        </div>
                        <h3 className="text-lg font-bold text-slate-900 mb-3 line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-slate-600 mb-4 line-clamp-3">
                          {post.excerpt || "Discover expert insights and proven strategies for property investment success."}
                        </p>
                        <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                          <div className="flex items-center">
                            <User className="mr-1 h-4 w-4" />
                            <span>{post.author?.firstName} {post.author?.lastName}</span>
                          </div>
                          <div className="flex items-center">
                            <Calendar className="mr-1 h-4 w-4" />
                            <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Button variant="outline" className="w-full">
                          Read Article
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Sample Content for Empty State */}
            {blogPosts.length === 0 && !isLoading && (
              <div className="space-y-12">
                {/* Sample Featured Article */}
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-6">Featured Article</h2>
                  <Card className="overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/2 bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center h-64 md:h-auto">
                        <div className="text-center p-8">
                          <TrendingUp className="mx-auto h-16 w-16 text-blue-600 mb-4" />
                          <h3 className="text-lg font-semibold text-blue-900">BRRR Strategy Guide</h3>
                        </div>
                      </div>
                      <div className="md:w-1/2 p-8">
                        <div className="flex items-center gap-2 mb-4">
                          <Badge variant="secondary">BRRR Strategy</Badge>
                          <span className="text-sm text-slate-500">Featured</span>
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 mb-4">
                          Complete Guide to BRRR Property Investment Strategy
                        </h3>
                        <p className="text-slate-600 mb-6 leading-relaxed">
                          Master the Buy, Refurb, Rent, Refinance strategy with our comprehensive guide. Learn how to build a profitable property portfolio using other people's money.
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center text-sm text-slate-500">
                            <User className="mr-1 h-4 w-4" />
                            <span className="mr-4">Excel Edge Team</span>
                            <Calendar className="mr-1 h-4 w-4" />
                            <span>Coming Soon</span>
                          </div>
                          <Button>
                            Read More
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Sample Articles Grid */}
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-6">Latest Articles</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {[
                      {
                        title: "Understanding Property Yields: Gross vs Net",
                        category: "Investment Tips",
                        excerpt: "Learn the difference between gross and net yields and how to calculate them accurately for your investment decisions.",
                        icon: Target
                      },
                      {
                        title: "Market Analysis: Manchester Property Trends 2024",
                        category: "Market Analysis",
                        excerpt: "Comprehensive analysis of Manchester's property market including price trends, rental yields, and growth projections.",
                        icon: TrendingUp
                      },
                      {
                        title: "Buy-to-Let Mortgage Guide for First-Time Investors",
                        category: "Buy-to-Let",
                        excerpt: "Everything you need to know about securing your first buy-to-let mortgage, including deposit requirements and rates.",
                        icon: Home
                      }
                    ].map((article, index) => (
                      <Card key={index} className="overflow-hidden">
                        <div className="h-48 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                          <article.icon className="h-16 w-16 text-slate-400" />
                        </div>
                        <CardContent className="p-6">
                          <div className="flex items-center gap-2 mb-3">
                            <Badge variant="outline">{article.category}</Badge>
                          </div>
                          <h3 className="text-lg font-bold text-slate-900 mb-3">
                            {article.title}
                          </h3>
                          <p className="text-slate-600 mb-4">
                            {article.excerpt}
                          </p>
                          <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                            <div className="flex items-center">
                              <User className="mr-1 h-4 w-4" />
                              <span>Excel Edge Team</span>
                            </div>
                            <div className="flex items-center">
                              <Calendar className="mr-1 h-4 w-4" />
                              <span>Coming Soon</span>
                            </div>
                          </div>
                          <Button variant="outline" className="w-full">
                            Read Article
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Newsletter Signup */}
        <Card className="mt-16 bg-gradient-to-r from-primary to-blue-700 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Stay Updated with Market Insights</h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Get weekly property market updates, investment tips, and exclusive deal alerts delivered to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                placeholder="Enter your email"
                className="bg-white text-slate-900 border-0"
              />
              <Button variant="secondary" className="bg-white text-primary hover:bg-slate-100">
                Subscribe
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
