import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/navigation";
import { 
  Users, 
  Plus, 
  Phone, 
  Mail, 
  Globe, 
  MapPin, 
  Briefcase,
  Shield,
  Star,
  CheckCircle
} from "lucide-react";
import { insertPartnerSchema } from "@shared/schema";
import type { Partner } from "@shared/schema";
import { z } from "zod";

const partnerFormSchema = insertPartnerSchema.extend({
  name: z.string().min(1, "Name is required"),
  type: z.enum(["agent", "contractor", "landlord", "solicitor", "surveyor"]),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
});

type PartnerFormData = z.infer<typeof partnerFormSchema>;

export default function Partners() {
  const { toast } = useToast();
  const [selectedType, setSelectedType] = useState<string>("all");

  const { data: partners = [], isLoading } = useQuery<Partner[]>({
    queryKey: ["/api/partners"],
  });

  const form = useForm<PartnerFormData>({
    resolver: zodResolver(partnerFormSchema),
    defaultValues: {
      name: "",
      type: "agent",
      email: "",
      phone: "",
      location: "",
      description: "",
      website: "",
    },
  });

  const submitPartnerMutation = useMutation({
    mutationFn: async (data: PartnerFormData) => {
      return apiRequest("POST", "/api/partners", data);
    },
    onSuccess: () => {
      toast({
        title: "Partner submitted successfully",
        description: "Thank you for your submission. We'll review and get back to you soon.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/partners"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit partner information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PartnerFormData) => {
    submitPartnerMutation.mutate(data);
  };

  const filteredPartners = selectedType === "all" 
    ? partners 
    : partners.filter(partner => partner.type === selectedType);

  const partnerTypes = [
    { value: "all", label: "All Partners", icon: Users },
    { value: "agent", label: "Estate Agents", icon: Briefcase },
    { value: "contractor", label: "Contractors", icon: Briefcase },
    { value: "landlord", label: "Landlords", icon: Users },
    { value: "solicitor", label: "Solicitors", icon: Shield },
    { value: "surveyor", label: "Surveyors", icon: CheckCircle },
  ];

  const getTypeLabel = (type: string) => {
    const typeMap: Record<string, string> = {
      agent: "Estate Agent",
      contractor: "Contractor",
      landlord: "Landlord",
      solicitor: "Solicitor",
      surveyor: "Surveyor",
    };
    return typeMap[type] || type;
  };

  const getTypeColor = (type: string) => {
    const colorMap: Record<string, string> = {
      agent: "bg-blue-100 text-blue-800",
      contractor: "bg-green-100 text-green-800",
      landlord: "bg-purple-100 text-purple-800",
      solicitor: "bg-red-100 text-red-800",
      surveyor: "bg-orange-100 text-orange-800",
    };
    return colorMap[type] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Professional Partners</h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Connect with verified property professionals including estate agents, contractors, solicitors, and more to support your investment journey.
          </p>
        </div>

        <Tabs defaultValue="directory" className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="directory" className="flex items-center">
              <Users className="mr-2 h-4 w-4" />
              Partner Directory
            </TabsTrigger>
            <TabsTrigger value="submit" className="flex items-center">
              <Plus className="mr-2 h-4 w-4" />
              Become a Partner
            </TabsTrigger>
          </TabsList>

          {/* Partner Directory */}
          <TabsContent value="directory" className="space-y-8">
            {/* Partner Type Filter */}
            <div className="flex flex-wrap gap-2 justify-center">
              {partnerTypes.map((type) => (
                <Button
                  key={type.value}
                  variant={selectedType === type.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedType(type.value)}
                  className="flex items-center"
                >
                  <type.icon className="mr-2 h-4 w-4" />
                  {type.label}
                </Button>
              ))}
            </div>

            {/* Partners Grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-4 bg-slate-200 rounded mb-2" />
                      <div className="h-4 bg-slate-200 rounded w-2/3 mb-4" />
                      <div className="h-20 bg-slate-200 rounded" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredPartners.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Users className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">
                    {selectedType === "all" ? "No partners found" : `No ${getTypeLabel(selectedType).toLowerCase()}s found`}
                  </h3>
                  <p className="text-slate-500 mb-4">
                    We're building our network of verified professionals. Check back soon!
                  </p>
                  <Button variant="outline" onClick={() => setSelectedType("all")}>
                    View All Partners
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPartners.map((partner) => (
                  <Card key={partner.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-slate-900 mb-2">{partner.name}</h3>
                          <Badge className={getTypeColor(partner.type)}>
                            {getTypeLabel(partner.type)}
                          </Badge>
                        </div>
                        {partner.verified && (
                          <div className="flex items-center text-green-600">
                            <CheckCircle className="h-5 w-5" />
                          </div>
                        )}
                      </div>

                      {partner.location && (
                        <div className="flex items-center text-slate-600 mb-3">
                          <MapPin className="mr-2 h-4 w-4" />
                          <span className="text-sm">{partner.location}</span>
                        </div>
                      )}

                      {partner.description && (
                        <p className="text-slate-600 text-sm mb-4 line-clamp-3">
                          {partner.description}
                        </p>
                      )}

                      <div className="space-y-2">
                        {partner.email && (
                          <div className="flex items-center text-slate-600">
                            <Mail className="mr-2 h-4 w-4" />
                            <a href={`mailto:${partner.email}`} className="text-sm hover:text-primary">
                              {partner.email}
                            </a>
                          </div>
                        )}
                        {partner.phone && (
                          <div className="flex items-center text-slate-600">
                            <Phone className="mr-2 h-4 w-4" />
                            <a href={`tel:${partner.phone}`} className="text-sm hover:text-primary">
                              {partner.phone}
                            </a>
                          </div>
                        )}
                        {partner.website && (
                          <div className="flex items-center text-slate-600">
                            <Globe className="mr-2 h-4 w-4" />
                            <a 
                              href={partner.website} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-sm hover:text-primary"
                            >
                              Visit Website
                            </a>
                          </div>
                        )}
                      </div>

                      <Button className="w-full mt-4" variant="outline">
                        Contact Partner
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Sample Partners when none exist */}
            {partners.length === 0 && !isLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    name: "Manchester Property Experts",
                    type: "agent",
                    location: "Manchester, UK",
                    description: "Specializing in buy-to-let properties across Greater Manchester with 15+ years experience.",
                  },
                  {
                    name: "Elite Property Contractors",
                    type: "contractor",
                    location: "Birmingham, UK",
                    description: "Full property refurbishment services for BRRR investors. Fast turnaround, quality guaranteed.",
                  },
                  {
                    name: "Property Law Associates",
                    type: "solicitor",
                    location: "London, UK",
                    description: "Specialist property solicitors offering competitive rates for buy-to-let purchases.",
                  }
                ].map((partner, index) => (
                  <Card key={index} className="opacity-75">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-slate-900 mb-2">{partner.name}</h3>
                          <Badge className={getTypeColor(partner.type)}>
                            {getTypeLabel(partner.type)}
                          </Badge>
                        </div>
                        <div className="flex items-center text-green-600">
                          <CheckCircle className="h-5 w-5" />
                        </div>
                      </div>

                      <div className="flex items-center text-slate-600 mb-3">
                        <MapPin className="mr-2 h-4 w-4" />
                        <span className="text-sm">{partner.location}</span>
                      </div>

                      <p className="text-slate-600 text-sm mb-4">
                        {partner.description}
                      </p>

                      <Button className="w-full" variant="outline" disabled>
                        Coming Soon
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Become a Partner */}
          <TabsContent value="submit" className="space-y-8">
            <div className="max-w-2xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="mr-2 h-5 w-5" />
                    Join Our Partner Network
                  </CardTitle>
                  <p className="text-slate-600">
                    Connect with property investors and grow your business. Submit your details to be considered for our verified partner directory.
                  </p>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Business Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your Business Name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Business Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select business type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="agent">Estate Agent</SelectItem>
                                  <SelectItem value="contractor">Contractor</SelectItem>
                                  <SelectItem value="landlord">Landlord</SelectItem>
                                  <SelectItem value="solicitor">Solicitor</SelectItem>
                                  <SelectItem value="surveyor">Surveyor</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input placeholder="contact@yourbusiness.com" type="email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="+44 123 456 7890" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Location/Service Area</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Manchester, Birmingham" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="website"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Website (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="https://yourbusiness.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Describe your services, experience, and how you can help property investors..."
                                rows={4}
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-blue-900 mb-2">Next Steps</h4>
                        <ul className="text-sm text-blue-800 space-y-1">
                          <li>• We'll review your application within 2-3 business days</li>
                          <li>• Our team may contact you for additional verification</li>
                          <li>• Once approved, you'll be added to our partner directory</li>
                          <li>• Start receiving qualified leads from property investors</li>
                        </ul>
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={submitPartnerMutation.isPending}
                      >
                        {submitPartnerMutation.isPending ? "Submitting..." : "Submit Application"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
