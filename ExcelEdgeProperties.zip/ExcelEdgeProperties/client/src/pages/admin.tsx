import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import Navigation from "@/components/navigation";
import DealCard from "@/components/deal-card";
import DealAnalysis from "@/components/deal-analysis";
import { 
  Settings, 
  Users, 
  FileText, 
  BarChart3, 
  CheckCircle, 
  XCircle, 
  Clock,
  Eye,
  MessageSquare,
  Star
} from "lucide-react";
import type { Deal, User as UserType, Testimonial, BlogPost } from "@shared/schema";

export default function Admin() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [selectedDeal, setSelectedDeal] = useState<Deal | null>(null);

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: allDeals = [] } = useQuery<Deal[]>({
    queryKey: ["/api/deals"],
    enabled: user?.role === "admin",
  });

  const { data: testimonials = [] } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
    enabled: user?.role === "admin",
  });

  const { data: blogPosts = [] } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog"],
    enabled: user?.role === "admin",
  });

  const updateDealMutation = useMutation({
    mutationFn: async ({ dealId, status }: { dealId: string; status: string }) => {
      return apiRequest("PUT", `/api/deals/${dealId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/deals"] });
      toast({
        title: "Deal updated",
        description: "Deal status has been updated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update deal status.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <Settings className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Access Restricted</h2>
              <p className="text-slate-600">Only administrators can access this page.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const pendingDeals = allDeals.filter(deal => deal.status === "pending");
  const approvedDeals = allDeals.filter(deal => deal.status === "approved");
  const rejectedDeals = allDeals.filter(deal => deal.status === "rejected");

  const handleApproveDeal = (dealId: string) => {
    updateDealMutation.mutate({ dealId, status: "approved" });
  };

  const handleRejectDeal = (dealId: string) => {
    updateDealMutation.mutate({ dealId, status: "rejected" });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Admin Dashboard</h1>
          <p className="text-slate-600">Manage platform operations, users, and content</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-500 text-sm">Total Users</span>
                <Users className="h-4 w-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900">1,247</div>
              <div className="text-sm text-green-600">+52 this week</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-500 text-sm">Active Deals</span>
                <FileText className="h-4 w-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900">{approvedDeals.length}</div>
              <div className="text-sm text-warning">{pendingDeals.length} pending</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-500 text-sm">Monthly Revenue</span>
                <BarChart3 className="h-4 w-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900">£28,450</div>
              <div className="text-sm text-green-600">+22% growth</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-500 text-sm">Platform Health</span>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </div>
              <div className="text-2xl font-bold text-green-600">Excellent</div>
              <div className="text-sm text-slate-500">99.9% uptime</div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Tabs */}
        <Tabs defaultValue="deals" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="deals" className="flex items-center">
              <FileText className="mr-2 h-4 w-4" />
              Deal Management
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center">
              <Users className="mr-2 h-4 w-4" />
              User Management
            </TabsTrigger>
            <TabsTrigger value="content" className="flex items-center">
              <MessageSquare className="mr-2 h-4 w-4" />
              Content
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center">
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Deal Management */}
          <TabsContent value="deals" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-warning">
                    <Clock className="mr-2 h-5 w-5" />
                    Pending Review
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-900 mb-2">{pendingDeals.length}</div>
                  <p className="text-sm text-slate-600">Deals awaiting approval</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-green-600">
                    <CheckCircle className="mr-2 h-5 w-5" />
                    Approved
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-900 mb-2">{approvedDeals.length}</div>
                  <p className="text-sm text-slate-600">Active on platform</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-red-600">
                    <XCircle className="mr-2 h-5 w-5" />
                    Rejected
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-900 mb-2">{rejectedDeals.length}</div>
                  <p className="text-sm text-slate-600">Not approved</p>
                </CardContent>
              </Card>
            </div>

            {/* Pending Deals for Review */}
            {pendingDeals.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Deals Pending Review</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {pendingDeals.map((deal) => (
                      <div key={deal.id} className="space-y-4">
                        <DealCard 
                          deal={deal} 
                          showActions={false}
                        />
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            className="flex-1"
                            onClick={() => setSelectedDeal(deal)}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            Review
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="text-green-600 border-green-600 hover:bg-green-50"
                            onClick={() => handleApproveDeal(deal.id)}
                            disabled={updateDealMutation.isPending}
                          >
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Approve
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="text-red-600 border-red-600 hover:bg-red-50"
                            onClick={() => handleRejectDeal(deal.id)}
                            disabled={updateDealMutation.isPending}
                          >
                            <XCircle className="mr-2 h-4 w-4" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* User Management */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Users className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">User Management</h3>
                  <p className="text-slate-600">Advanced user management features coming soon.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Management */}
          <TabsContent value="content" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="mr-2 h-5 w-5" />
                    Testimonials
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-2xl font-bold text-slate-900">{testimonials.length}</div>
                    <p className="text-sm text-slate-600">
                      {testimonials.filter(t => t.approved).length} approved, {testimonials.filter(t => !t.approved).length} pending
                    </p>
                    <Button variant="outline" size="sm">
                      Manage Testimonials
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="mr-2 h-5 w-5" />
                    Blog Posts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-2xl font-bold text-slate-900">{blogPosts.length}</div>
                    <p className="text-sm text-slate-600">
                      {blogPosts.filter(p => p.published).length} published, {blogPosts.filter(p => !p.published).length} drafts
                    </p>
                    <Button variant="outline" size="sm">
                      Manage Blog Posts
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <BarChart3 className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Advanced Analytics</h3>
                  <p className="text-slate-600">Detailed analytics dashboard coming soon.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Deal Review Modal */}
      <Dialog open={!!selectedDeal} onOpenChange={() => setSelectedDeal(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Review Deal: {selectedDeal?.title}</DialogTitle>
          </DialogHeader>
          {selectedDeal && (
            <div className="space-y-6">
              <DealAnalysis deal={selectedDeal} />
              
              {selectedDeal.description && (
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-slate-900 mb-4">Description</h3>
                    <p className="text-slate-700 whitespace-pre-wrap">{selectedDeal.description}</p>
                  </CardContent>
                </Card>
              )}

              <div className="flex gap-4">
                <Button 
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => {
                    handleApproveDeal(selectedDeal.id);
                    setSelectedDeal(null);
                  }}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Approve Deal
                </Button>
                <Button 
                  variant="destructive" 
                  className="flex-1"
                  onClick={() => {
                    handleRejectDeal(selectedDeal.id);
                    setSelectedDeal(null);
                  }}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject Deal
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
