import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/navigation";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  CreditCard, 
  Shield, 
  CheckCircle, 
  ArrowLeft, 
  Loader2,
  PoundSterling,
  Building2
} from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface PaymentDetails {
  amount: number;
  currency: string;
  description: string;
  dealId?: string;
  dealTitle?: string;
  type: 'sourcing_fee' | 'deposit' | 'commission' | 'subscription';
}

const CheckoutForm = ({ paymentDetails }: { paymentDetails: PaymentDetails }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard?payment=success`,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Payment Successful",
          description: "Thank you for your payment!",
        });
      }
    } catch (err) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CreditCard className="mr-2 h-5 w-5" />
            Payment Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PaymentElement 
            options={{
              layout: "tabs"
            }}
          />
        </CardContent>
      </Card>

      <Button 
        type="submit" 
        className="w-full" 
        size="lg"
        disabled={!stripe || !elements || isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing Payment...
          </>
        ) : (
          <>
            <Shield className="mr-2 h-4 w-4" />
            Complete Payment - {paymentDetails.currency === 'gbp' ? '£' : '₦'}{paymentDetails.amount.toLocaleString()}
          </>
        )}
      </Button>

      <div className="text-center text-sm text-slate-500">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Shield className="h-4 w-4" />
          <span>Secured by Stripe</span>
        </div>
        <p>Your payment information is encrypted and secure</p>
      </div>
    </form>
  );
};

export default function Checkout() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);

  // Get payment details from URL params or state
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const amount = urlParams.get('amount');
    const currency = urlParams.get('currency') || 'gbp';
    const type = urlParams.get('type') || 'sourcing_fee';
    const dealId = urlParams.get('dealId');
    const dealTitle = urlParams.get('dealTitle');
    const description = urlParams.get('description') || 'Property investment payment';

    if (amount) {
      setPaymentDetails({
        amount: parseFloat(amount),
        currency,
        description,
        dealId: dealId || undefined,
        dealTitle: dealTitle || undefined,
        type: type as PaymentDetails['type']
      });
    } else {
      // Default payment details if none provided
      setPaymentDetails({
        amount: 2500,
        currency: 'gbp',
        description: 'Property sourcing fee',
        type: 'sourcing_fee'
      });
    }
  }, []);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to complete your payment.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Create PaymentIntent when component mounts and user is authenticated
  useEffect(() => {
    if (isAuthenticated && paymentDetails && !clientSecret) {
      const createPaymentIntent = async () => {
        try {
          const response = await apiRequest("POST", "/api/create-payment-intent", { 
            amount: paymentDetails.amount,
            currency: paymentDetails.currency,
            description: paymentDetails.description,
            dealId: paymentDetails.dealId,
            type: paymentDetails.type
          });
          const data = await response.json();
          setClientSecret(data.clientSecret);
        } catch (error) {
          if (isUnauthorizedError(error as Error)) {
            toast({
              title: "Session Expired",
              description: "Please log in again to complete your payment.",
              variant: "destructive",
            });
            setTimeout(() => {
              window.location.href = "/api/login";
            }, 1000);
            return;
          }
          toast({
            title: "Payment Setup Failed",
            description: "Failed to initialize payment. Please try again.",
            variant: "destructive",
          });
        }
      };

      createPaymentIntent();
    }
  }, [isAuthenticated, paymentDetails, clientSecret, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
            <p className="mt-2 text-slate-600">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  if (!paymentDetails) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <CreditCard className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Invalid Payment Request</h2>
              <p className="text-slate-600 mb-4">No payment details were provided.</p>
              <Button onClick={() => window.history.back()}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary mb-4" />
            <h2 className="text-xl font-semibold text-slate-900 mb-2">Setting up payment...</h2>
            <p className="text-slate-600">Please wait while we prepare your secure payment.</p>
          </div>
        </div>
      </div>
    );
  }

  const getPaymentTypeLabel = (type: string) => {
    switch (type) {
      case 'sourcing_fee': return 'Property Sourcing Fee';
      case 'deposit': return 'Property Deposit';
      case 'commission': return 'Commission Payment';
      case 'subscription': return 'Platform Subscription';
      default: return 'Payment';
    }
  };

  const getPaymentTypeDescription = (type: string) => {
    switch (type) {
      case 'sourcing_fee': return 'Fee for property sourcing services';
      case 'deposit': return 'Deposit payment for property purchase';
      case 'commission': return 'Commission payment to sourcer';
      case 'subscription': return 'Monthly platform subscription';
      default: return 'Payment processing';
    }
  };

  // Make SURE to wrap the form in <Elements> which provides the stripe context.
  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />
      
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={() => window.history.back()}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Complete Payment</h1>
          <p className="text-slate-600">Secure payment processing powered by Stripe</p>
        </div>

        {/* Payment Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building2 className="mr-2 h-5 w-5" />
              Payment Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Service:</span>
                <Badge variant="secondary">{getPaymentTypeLabel(paymentDetails.type)}</Badge>
              </div>
              
              {paymentDetails.dealTitle && (
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">Property:</span>
                  <span className="font-medium text-slate-900">{paymentDetails.dealTitle}</span>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-slate-600">Description:</span>
                <span className="text-slate-900">{getPaymentTypeDescription(paymentDetails.type)}</span>
              </div>

              <Separator />

              <div className="flex items-center justify-between text-lg font-semibold">
                <span>Total Amount:</span>
                <div className="flex items-center">
                  {paymentDetails.currency === 'gbp' ? (
                    <PoundSterling className="mr-1 h-5 w-5" />
                  ) : (
                    <span className="mr-1">₦</span>
                  )}
                  <span>{paymentDetails.amount.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Form */}
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <CheckoutForm paymentDetails={paymentDetails} />
        </Elements>

        {/* Security Information */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-2">Secure Payment</h3>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Your payment information is encrypted and secure</li>
                  <li>• We never store your card details on our servers</li>
                  <li>• All transactions are processed by Stripe</li>
                  <li>• You'll receive a receipt via email once payment is complete</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support */}
        <div className="mt-8 text-center text-sm text-slate-500">
          <p>Need help? Contact our support team for assistance.</p>
          <p className="mt-1">
            Email: <a href="mailto:support@exceledgeproperties.com" className="text-primary hover:underline">
              support@exceledgeproperties.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
