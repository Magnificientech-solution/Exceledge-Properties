import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import DealCard from "@/components/deal-card";
import { 
  BarChart3, 
  TrendingUp, 
  PoundSterling, 
  Users, 
  Calendar,
  MessageSquare,
  Plus,
  CheckCircle,
  Clock,
  Eye,
  Target
} from "lucide-react";
import type { Deal, DealInterest, User } from "@shared/schema";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: myDeals = [] } = useQuery<Deal[]>({
    queryKey: ["/api/my-deals"],
    enabled: user?.role === "sourcer",
  });

  const { data: myInterests = [] } = useQuery<(DealInterest & { deal: Deal })[]>({
    queryKey: ["/api/my-interests"],
    enabled: user?.role === "investor",
  });

  const { data: recentDeals = [] } = useQuery<Deal[]>({
    queryKey: ["/api/deals?status=approved&limit=4"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  const approvedDeals = myDeals.filter(deal => deal.status === "approved").length;
  const pendingDeals = myDeals.filter(deal => deal.status === "pending").length;
  const totalViews = myDeals.reduce((sum, deal) => sum + 50, 0); // Mock view count

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Welcome back, {user?.firstName}!
          </h1>
          <p className="text-slate-600">
            {user?.role === "investor" 
              ? "Track your portfolio and discover new investment opportunities"
              : user?.role === "sourcer"
              ? "Manage your property listings and track performance"
              : "Manage platform operations and user activities"
            }
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Dashboard Area */}
          <div className="lg:col-span-3 space-y-8">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {user?.role === "investor" ? (
                <>
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Portfolio Value</span>
                        <PoundSterling className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">£485,000</div>
                      <div className="text-sm text-green-600">+12.5% this year</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Monthly Income</span>
                        <TrendingUp className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">£3,240</div>
                      <div className="text-sm text-green-600">+8.2% vs last month</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Average Yield</span>
                        <BarChart3 className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">8.7%</div>
                      <div className="text-sm text-green-600">Above market avg</div>
                    </CardContent>
                  </Card>
                </>
              ) : user?.role === "sourcer" ? (
                <>
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Active Listings</span>
                        <Target className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">{approvedDeals}</div>
                      <div className="text-sm text-slate-500">{pendingDeals} pending</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Total Views</span>
                        <Eye className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">{totalViews.toLocaleString()}</div>
                      <div className="text-sm text-green-600">+15% this month</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Conversion Rate</span>
                        <TrendingUp className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">24%</div>
                      <div className="text-sm text-green-600">+3% improvement</div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <>
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Total Users</span>
                        <Users className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">1,247</div>
                      <div className="text-sm text-green-600">+52 this week</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Active Deals</span>
                        <Target className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">342</div>
                      <div className="text-sm text-green-600">18 pending review</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-500 text-sm">Platform Revenue</span>
                        <PoundSterling className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-bold text-slate-900">£28,450</div>
                      <div className="text-sm text-green-600">+22% this month</div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {user?.role === "investor" ? (
                    myInterests.slice(0, 5).map((interest) => (
                      <div key={interest.id} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                            {interest.status === "interested" ? <Clock className="text-warning h-5 w-5" /> : <CheckCircle className="text-green-600 h-5 w-5" />}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{interest.deal?.title}</div>
                            <div className="text-sm text-slate-500">
                              {interest.status === "interested" ? "Expressed interest" : "Status updated"} • {new Date(interest.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        <Badge variant={interest.status === "interested" ? "secondary" : "default"}>
                          {interest.status}
                        </Badge>
                      </div>
                    ))
                  ) : user?.role === "sourcer" ? (
                    myDeals.slice(0, 5).map((deal) => (
                      <div key={deal.id} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                            {deal.status === "approved" ? <CheckCircle className="text-green-600 h-5 w-5" /> : <Clock className="text-warning h-5 w-5" />}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{deal.title}</div>
                            <div className="text-sm text-slate-500">
                              Listed • {new Date(deal.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        <Badge variant={deal.status === "approved" ? "default" : "secondary"}>
                          {deal.status}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    // Admin activity view
                    <div className="space-y-4">
                      <div className="flex items-center justify-between py-3 border-b border-slate-100">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                            <Users className="text-blue-600 h-5 w-5" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">New user registrations</div>
                            <div className="text-sm text-slate-500">52 new users this week</div>
                          </div>
                        </div>
                        <Badge>+52</Badge>
                      </div>
                      <div className="flex items-center justify-between py-3 border-b border-slate-100">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center mr-3">
                            <Clock className="text-warning h-5 w-5" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">Deals pending review</div>
                            <div className="text-sm text-slate-500">18 deals awaiting approval</div>
                          </div>
                        </div>
                        <Badge variant="secondary">18</Badge>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Recent Deals */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-900">
                  {user?.role === "investor" ? "New Opportunities" : user?.role === "sourcer" ? "Your Listings" : "Platform Activity"}
                </h2>
                <Button variant="outline">
                  View All
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {(user?.role === "sourcer" ? myDeals : recentDeals).slice(0, 4).map((deal) => (
                  <DealCard key={deal.id} deal={deal} />
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {user?.role === "investor" ? (
                  <>
                    <Button className="w-full justify-start" size="sm">
                      <Target className="mr-2 h-4 w-4" />
                      Browse New Deals
                      <Badge variant="secondary" className="ml-auto">42</Badge>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <BarChart3 className="mr-2 h-4 w-4" />
                      Portfolio Analytics
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Messages
                      <Badge variant="destructive" className="ml-auto">3</Badge>
                    </Button>
                  </>
                ) : user?.role === "sourcer" ? (
                  <>
                    <Button className="w-full justify-start" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Submit New Deal
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <BarChart3 className="mr-2 h-4 w-4" />
                      Performance Analytics
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Investor Messages
                      <Badge variant="destructive" className="ml-auto">5</Badge>
                    </Button>
                  </>
                ) : (
                  <>
                    <Button className="w-full justify-start" size="sm">
                      <Users className="mr-2 h-4 w-4" />
                      Manage Users
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <Clock className="mr-2 h-4 w-4" />
                      Review Deals
                      <Badge variant="secondary" className="ml-auto">18</Badge>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <BarChart3 className="mr-2 h-4 w-4" />
                      Platform Analytics
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Market Insights */}
            <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white">
              <CardContent className="p-6">
                <h4 className="font-semibold mb-2">Market Insight</h4>
                <p className="text-sm text-green-100 mb-4">
                  Manchester yields up 0.3% this quarter. Great time to invest in the North West.
                </p>
                <Button variant="outline" size="sm" className="border-white/30 text-white hover:bg-white/10">
                  Read Full Report
                </Button>
              </CardContent>
            </Card>

            {/* Performance Summary */}
            <Card>
              <CardHeader>
                <CardTitle>This Month</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">
                      {user?.role === "investor" ? "Properties Viewed" : user?.role === "sourcer" ? "Deal Submissions" : "New Users"}
                    </span>
                    <span className="font-bold text-slate-900">
                      {user?.role === "investor" ? "127" : user?.role === "sourcer" ? "8" : "52"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">
                      {user?.role === "investor" ? "Offers Made" : user?.role === "sourcer" ? "Approved Deals" : "Total Deals"}
                    </span>
                    <span className="font-bold text-slate-900">
                      {user?.role === "investor" ? "3" : user?.role === "sourcer" ? "5" : "342"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">
                      {user?.role === "investor" ? "Messages Sent" : user?.role === "sourcer" ? "Inquiries Received" : "Revenue Generated"}
                    </span>
                    <span className="font-bold text-slate-900">
                      {user?.role === "investor" ? "18" : user?.role === "sourcer" ? "24" : "£28,450"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
