import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import Navigation from "@/components/navigation";
import DealCard from "@/components/deal-card";
import DealAnalysis from "@/components/deal-analysis";
import { Search, Filter, MapPin, TrendingUp } from "lucide-react";
import type { Deal } from "@shared/schema";

export default function Deals() {
  const [selectedDeal, setSelectedDeal] = useState<Deal | null>(null);
  const [filters, setFilters] = useState({
    search: "",
    strategy: "",
    location: "",
    status: "approved",
  });

  const { data: deals = [], isLoading } = useQuery<Deal[]>({
    queryKey: ["/api/deals", filters.status, filters.strategy, filters.location],
  });

  const filteredDeals = deals.filter(deal => 
    deal.title.toLowerCase().includes(filters.search.toLowerCase()) ||
    deal.location.toLowerCase().includes(filters.search.toLowerCase())
  );

  const handleViewDetails = (deal: Deal) => {
    setSelectedDeal(deal);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Property Deals</h1>
          <p className="text-slate-600">Discover investment opportunities with detailed analysis and verified data</p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search deals..."
                  value={filters.search}
                  onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                  className="pl-10"
                />
              </div>

              <Select value={filters.strategy || "all"} onValueChange={(value) => setFilters({ ...filters, strategy: value === "all" ? "" : value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Strategy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Strategies</SelectItem>
                  <SelectItem value="buy-to-let">Buy-to-Let</SelectItem>
                  <SelectItem value="brrr">BRRR</SelectItem>
                  <SelectItem value="bmv">BMV</SelectItem>
                  <SelectItem value="commercial">Commercial</SelectItem>
                </SelectContent>
              </Select>

              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Location"
                  value={filters.location}
                  onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                  className="pl-10"
                />
              </div>

              <Button variant="outline" className="w-full">
                <Filter className="mr-2 h-4 w-4" />
                More Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-slate-900">{filteredDeals.length}</div>
              <div className="text-sm text-slate-500">Available Deals</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-slate-900">8.2%</div>
              <div className="text-sm text-slate-500">Average Yield</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-slate-900">£185k</div>
              <div className="text-sm text-slate-500">Average Price</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-slate-900">22</div>
              <div className="text-sm text-slate-500">New This Week</div>
            </CardContent>
          </Card>
        </div>

        {/* Deals Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-48 bg-slate-200" />
                <CardContent className="p-6">
                  <div className="h-4 bg-slate-200 rounded mb-2" />
                  <div className="h-4 bg-slate-200 rounded w-2/3 mb-4" />
                  <div className="grid grid-cols-2 gap-4">
                    <div className="h-8 bg-slate-200 rounded" />
                    <div className="h-8 bg-slate-200 rounded" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredDeals.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <TrendingUp className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">No deals found</h3>
              <p className="text-slate-500 mb-4">Try adjusting your search criteria or check back later for new opportunities.</p>
              <Button variant="outline">Clear Filters</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDeals.map((deal) => (
              <DealCard
                key={deal.id}
                deal={deal}
                onViewDetails={() => handleViewDetails(deal)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Deal Details Modal */}
      <Dialog open={!!selectedDeal} onOpenChange={() => setSelectedDeal(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" aria-describedby="deal-description">
          <DialogHeader>
            <DialogTitle>{selectedDeal?.title}</DialogTitle>
          </DialogHeader>
          {selectedDeal && (
            <div className="space-y-6">
              {/* Deal Images */}
              {selectedDeal.images && selectedDeal.images.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedDeal.images.slice(0, 4).map((image, index) => (
                    <img
                      key={index}
                      src={image}
                      alt={`${selectedDeal.title} - Image ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  ))}
                </div>
              )}

              {/* Deal Analysis */}
              <DealAnalysis deal={selectedDeal} />

              {/* Description */}
              {selectedDeal.description && (
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-slate-900 mb-4">Description</h3>
                    <p id="deal-description" className="text-slate-700 whitespace-pre-wrap">{selectedDeal.description}</p>
                  </CardContent>
                </Card>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button className="flex-1">
                  Express Interest
                </Button>
                <Button variant="outline" className="flex-1">
                  Contact Sourcer
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
