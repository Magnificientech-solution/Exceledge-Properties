import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/navigation";
import { Star, Plus, User, Quote, Filter, MapPin } from "lucide-react";
import { insertTestimonialSchema } from "@shared/schema";
import type { Testimonial, User as UserType } from "@shared/schema";
import { z } from "zod";

const testimonialFormSchema = insertTestimonialSchema.extend({
  content: z.string().min(10, "Testimonial must be at least 10 characters"),
  rating: z.number().min(1).max(5),
});

type TestimonialFormData = z.infer<typeof testimonialFormSchema>;

export default function Testimonials() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [filterStrategy, setFilterStrategy] = useState<string>("all");
  const [filterLocation, setFilterLocation] = useState<string>("all");

  const { data: testimonials = [], isLoading } = useQuery<(Testimonial & { user: UserType })[]>({
    queryKey: ["/api/testimonials"],
  });

  const form = useForm<TestimonialFormData>({
    resolver: zodResolver(testimonialFormSchema),
    defaultValues: {
      content: "",
      rating: 5,
      strategy: "",
      location: "",
    },
  });

  const submitTestimonialMutation = useMutation({
    mutationFn: async (data: TestimonialFormData) => {
      return apiRequest("POST", "/api/testimonials", data);
    },
    onSuccess: () => {
      toast({
        title: "Testimonial submitted successfully",
        description: "Thank you for sharing your experience! It will be reviewed before being published.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/testimonials"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit testimonial. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TestimonialFormData) => {
    if (!isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to submit a testimonial.",
        variant: "destructive",
      });
      return;
    }
    submitTestimonialMutation.mutate(data);
  };

  const filteredTestimonials = testimonials.filter(testimonial => {
    const strategyMatch = filterStrategy === "all" || testimonial.strategy === filterStrategy;
    const locationMatch = filterLocation === "all" || testimonial.location === filterLocation;
    return strategyMatch && locationMatch;
  });

  const uniqueStrategies = Array.from(new Set(testimonials.map(t => t.strategy).filter(Boolean)));
  const uniqueLocations = Array.from(new Set(testimonials.map(t => t.location).filter(Boolean)));

  const renderStars = (rating: number) => {
    return [...Array(5)].map((_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'fill-warning text-warning' : 'text-slate-300'}`}
      />
    ));
  };

  const averageRating = testimonials.length > 0 
    ? testimonials.reduce((sum, t) => sum + t.rating, 0) / testimonials.length 
    : 0;

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Success Stories</h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Real experiences from property investors who've built successful portfolios using Excel Edge Properties.
          </p>
          
          {/* Stats */}
          <div className="flex justify-center items-center gap-8 mt-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-slate-900">{testimonials.length}</div>
              <div className="text-sm text-slate-500">Happy Investors</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-1">
                <span className="text-3xl font-bold text-slate-900 mr-2">{averageRating.toFixed(1)}</span>
                <div className="flex">
                  {renderStars(Math.round(averageRating))}
                </div>
              </div>
              <div className="text-sm text-slate-500">Average Rating</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-slate-900">£2.4M+</div>
              <div className="text-sm text-slate-500">Properties Sourced</div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="testimonials" className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="testimonials" className="flex items-center">
              <Quote className="mr-2 h-4 w-4" />
              Read Reviews
            </TabsTrigger>
            <TabsTrigger value="submit" className="flex items-center">
              <Plus className="mr-2 h-4 w-4" />
              Share Your Story
            </TabsTrigger>
          </TabsList>

          {/* Testimonials */}
          <TabsContent value="testimonials" className="space-y-8">
            {/* Filters */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-wrap gap-4 items-center">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4 text-slate-500" />
                    <span className="text-sm font-medium text-slate-700">Filter by:</span>
                  </div>
                  
                  <Select value={filterStrategy} onValueChange={setFilterStrategy}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Strategy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Strategies</SelectItem>
                      {uniqueStrategies.map(strategy => (
                        <SelectItem key={strategy} value={strategy!}>{strategy}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={filterLocation} onValueChange={setFilterLocation}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Locations</SelectItem>
                      {uniqueLocations.map(location => (
                        <SelectItem key={location} value={location!}>{location}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {(filterStrategy !== "all" || filterLocation !== "all") && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setFilterStrategy("all");
                        setFilterLocation("all");
                      }}
                    >
                      Clear Filters
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Testimonials Grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-4 bg-slate-200 rounded mb-2" />
                      <div className="h-4 bg-slate-200 rounded w-2/3 mb-4" />
                      <div className="h-20 bg-slate-200 rounded" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredTestimonials.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Quote className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No testimonials found</h3>
                  <p className="text-slate-500 mb-4">
                    {filterStrategy !== "all" || filterLocation !== "all" 
                      ? "Try adjusting your filters or be the first to share your success story!"
                      : "Be the first to share your success story!"
                    }
                  </p>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setFilterStrategy("all");
                      setFilterLocation("all");
                    }}
                  >
                    Clear Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTestimonials.map((testimonial) => (
                  <Card key={testimonial.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      {/* Rating */}
                      <div className="flex items-center mb-4">
                        <div className="flex mr-2">
                          {renderStars(testimonial.rating)}
                        </div>
                        <span className="text-sm text-slate-600">{testimonial.rating}.0</span>
                      </div>

                      {/* Content */}
                      <p className="text-slate-700 mb-6 leading-relaxed">
                        "{testimonial.content}"
                      </p>

                      {/* User Info */}
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-slate-200 rounded-full flex items-center justify-center mr-3">
                          <User className="h-6 w-6 text-slate-400" />
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">
                            {testimonial.user?.firstName} {testimonial.user?.lastName}
                          </div>
                          <div className="text-sm text-slate-500">Property Investor</div>
                        </div>
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2">
                        {testimonial.strategy && (
                          <Badge variant="secondary">{testimonial.strategy}</Badge>
                        )}
                        {testimonial.location && (
                          <Badge variant="outline" className="flex items-center">
                            <MapPin className="mr-1 h-3 w-3" />
                            {testimonial.location}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Sample Testimonials when none exist */}
            {testimonials.length === 0 && !isLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    rating: 5,
                    content: "The deal analysis tools saved me weeks of research. I've successfully purchased 3 properties through Excel Edge and achieved an average yield of 9.2%.",
                    user: { firstName: "James", lastName: "Mitchell" },
                    strategy: "BRRR",
                    location: "London"
                  },
                  {
                    rating: 5,
                    content: "As a sourcer, this platform has connected me with serious investors. The verification process builds trust and the payment system is seamless.",
                    user: { firstName: "Sarah", lastName: "Chen" },
                    strategy: "Buy-to-Let",
                    location: "Manchester"
                  },
                  {
                    rating: 5,
                    content: "Excellent platform for expanding into Nigerian real estate. The multi-currency support and local expertise made international investing straightforward.",
                    user: { firstName: "David", lastName: "Okafor" },
                    strategy: "Commercial",
                    location: "Lagos"
                  }
                ].map((testimonial, index) => (
                  <Card key={index} className="opacity-75">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-4">
                        <div className="flex mr-2">
                          {renderStars(testimonial.rating)}
                        </div>
                        <span className="text-sm text-slate-600">{testimonial.rating}.0</span>
                      </div>

                      <p className="text-slate-700 mb-6 leading-relaxed">
                        "{testimonial.content}"
                      </p>

                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-slate-200 rounded-full flex items-center justify-center mr-3">
                          <User className="h-6 w-6 text-slate-400" />
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">
                            {testimonial.user.firstName} {testimonial.user.lastName}
                          </div>
                          <div className="text-sm text-slate-500">Property Investor</div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <Badge variant="secondary">{testimonial.strategy}</Badge>
                        <Badge variant="outline" className="flex items-center">
                          <MapPin className="mr-1 h-3 w-3" />
                          {testimonial.location}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Submit Testimonial */}
          <TabsContent value="submit" className="space-y-8">
            <div className="max-w-2xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="mr-2 h-5 w-5" />
                    Share Your Success Story
                  </CardTitle>
                  <p className="text-slate-600">
                    Help other investors by sharing your experience with Excel Edge Properties. Your testimonial will be reviewed before being published.
                  </p>
                </CardHeader>
                <CardContent>
                  {!isAuthenticated ? (
                    <div className="text-center py-8">
                      <User className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                      <h3 className="text-lg font-semibold text-slate-900 mb-2">Login Required</h3>
                      <p className="text-slate-600 mb-4">Please log in to share your testimonial.</p>
                      <Button onClick={() => window.location.href = "/api/login"}>
                        Log In
                      </Button>
                    </div>
                  ) : (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="rating"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Rating</FormLabel>
                              <FormControl>
                                <div className="flex items-center gap-2">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <button
                                      key={star}
                                      type="button"
                                      onClick={() => field.onChange(star)}
                                      className="focus:outline-none"
                                    >
                                      <Star
                                        className={`h-6 w-6 ${star <= field.value ? 'fill-warning text-warning' : 'text-slate-300'}`}
                                      />
                                    </button>
                                  ))}
                                  <span className="ml-2 text-sm text-slate-600">
                                    {field.value} star{field.value !== 1 ? 's' : ''}
                                  </span>
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="content"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Experience</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Share your experience with Excel Edge Properties. What worked well? How did we help you achieve your investment goals?"
                                  rows={6}
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="strategy"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Investment Strategy (Optional)</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., BRRR, Buy-to-Let" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="location"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Location (Optional)</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Manchester, Birmingham" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="bg-blue-50 p-4 rounded-lg">
                          <h4 className="font-semibold text-blue-900 mb-2">Before you submit:</h4>
                          <ul className="text-sm text-blue-800 space-y-1">
                            <li>• Your testimonial will be reviewed before being published</li>
                            <li>• Only your first name and last initial will be displayed</li>
                            <li>• We may contact you for verification purposes</li>
                            <li>• You can request removal at any time</li>
                          </ul>
                        </div>

                        <Button 
                          type="submit" 
                          className="w-full"
                          disabled={submitTestimonialMutation.isPending}
                        >
                          {submitTestimonialMutation.isPending ? "Submitting..." : "Submit Testimonial"}
                        </Button>
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
