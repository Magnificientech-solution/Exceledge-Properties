import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Deals from "@/pages/deals";
import SubmitDeal from "@/pages/submit-deal";
import Dashboard from "@/pages/dashboard";
import Admin from "@/pages/admin";
import Blog from "@/pages/blog";
import Partners from "@/pages/partners";
import Testimonials from "@/pages/testimonials";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/deals" component={Deals} />
          <Route path="/blog" component={Blog} />
          <Route path="/partners" component={Partners} />
          <Route path="/testimonials" component={Testimonials} />
        </>
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/deals" component={Deals} />
          <Route path="/submit-deal" component={SubmitDeal} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/admin" component={Admin} />
          <Route path="/blog" component={Blog} />
          <Route path="/partners" component={Partners} />
          <Route path="/testimonials" component={Testimonials} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
