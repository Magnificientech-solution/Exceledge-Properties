import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Bed, Bath, Square, TrendingUp } from "lucide-react";
import type { Deal } from "@shared/schema";

interface DealCardProps {
  deal: Deal;
  showActions?: boolean;
  onViewDetails?: () => void;
}

export default function DealCard({ deal, showActions = true, onViewDetails }: DealCardProps) {
  const formatCurrency = (value: string | null, currency = "GBP") => {
    if (!value) return "N/A";
    const num = parseFloat(value);
    if (currency === "GBP") {
      return `£${num.toLocaleString()}`;
    } else if (currency === "NGN") {
      return `₦${num.toLocaleString()}`;
    }
    return num.toLocaleString();
  };

  const getStrategyColor = (strategy: string) => {
    switch (strategy) {
      case "buy-to-let": return "bg-primary/15 text-primary border-primary/30";
      case "brrr": return "bg-[hsl(225,60%,95%)] text-[hsl(225,70%,40%)] border-[hsl(225,60%,80%)]";
      case "bmv": return "bg-[hsl(225,65%,92%)] text-[hsl(225,75%,35%)] border-[hsl(225,65%,75%)]";
      case "commercial": return "bg-[hsl(225,80%,90%)] text-[hsl(225,85%,30%)] border-[hsl(225,80%,70%)]";
      default: return "bg-muted text-muted-foreground border-border";
    }
  };

  const getStrategyLabel = (strategy: string) => {
    switch (strategy) {
      case "brrr": return "BRRR Ready";
      case "bmv": return "BMV Deal";
      case "commercial": return "Commercial";
      case "buy-to-let": return "Buy-to-Let";
      default: return strategy.toUpperCase();
    }
  };

  const grossYield = deal.analysis?.grossYield || 0;
  const roi = deal.analysis?.roi || 0;

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-[hsl(225,40%,85%)] group">
      {deal.images && deal.images.length > 0 && (
        <div className="h-52 bg-gradient-to-br from-[hsl(225,50%,96%)] to-[hsl(225,40%,92%)] relative overflow-hidden">
          <img 
            src={deal.images[0]} 
            alt={deal.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
        </div>
      )}
      
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <Badge className={`${getStrategyColor(deal.strategy)} border font-semibold px-3 py-1 rounded-full`}>
            {getStrategyLabel(deal.strategy)}
          </Badge>
          {grossYield > 0 && (
            <span className="bg-gradient-to-r from-primary to-[hsl(225,80%,45%)] text-white font-bold text-lg px-3 py-1 rounded-full shadow-lg">
              {grossYield.toFixed(1)}% Yield
            </span>
          )}
        </div>
        
        <h3 className="text-xl font-bold text-foreground mb-3 line-clamp-2">{deal.title}</h3>
        <p className="text-muted-foreground mb-6 flex items-center">
          <MapPin className="mr-2 h-4 w-4 text-primary" />
          {deal.location}
        </p>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-[hsl(225,50%,96%)] p-4 rounded-xl border border-[hsl(225,40%,85%)]">
            <div className="text-sm text-muted-foreground font-medium mb-1">Purchase Price</div>
            <div className="font-bold text-foreground text-lg">
              {formatCurrency(deal.price, deal.location.includes("Lagos") ? "NGN" : "GBP")}
            </div>
          </div>
          <div className="bg-gradient-to-br from-primary/8 to-[hsl(225,50%,96%)] p-4 rounded-xl border border-primary/25">
            <div className="text-sm text-muted-foreground font-medium mb-1">Monthly Rent</div>
            <div className="font-bold text-foreground text-lg">
              {formatCurrency(deal.monthlyRent, deal.location.includes("Lagos") ? "NGN" : "GBP")}
            </div>
          </div>
          {deal.refurbCost && (
            <div>
              <div className="text-sm text-slate-500">Refurb Cost</div>
              <div className="font-bold text-slate-900">
                {formatCurrency(deal.refurbCost, deal.location.includes("Lagos") ? "NGN" : "GBP")}
              </div>
            </div>
          )}
          {roi > 0 && (
            <div>
              <div className="text-sm text-slate-500">ROI</div>
              <div className="font-bold text-secondary">{roi.toFixed(1)}%</div>
            </div>
          )}
        </div>

        {/* Property Details */}
        {(deal.bedrooms || deal.bathrooms || deal.squareFeet) && (
          <div className="flex items-center gap-4 mb-4 text-sm text-slate-600">
            {deal.bedrooms && (
              <div className="flex items-center">
                <Bed className="mr-1 h-4 w-4" />
                {deal.bedrooms} bed
              </div>
            )}
            {deal.bathrooms && (
              <div className="flex items-center">
                <Bath className="mr-1 h-4 w-4" />
                {deal.bathrooms} bath
              </div>
            )}
            {deal.squareFeet && (
              <div className="flex items-center">
                <Square className="mr-1 h-4 w-4" />
                {deal.squareFeet} sq ft
              </div>
            )}
          </div>
        )}
        
        {showActions && (
          <Button 
            className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105" 
            onClick={onViewDetails}
          >
            View Full Analysis
            <TrendingUp className="ml-2 h-5 w-5" />
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
