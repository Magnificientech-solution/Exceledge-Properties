import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Calculator, PoundSterling, Percent } from "lucide-react";
import type { Deal } from "@shared/schema";

interface DealAnalysisProps {
  deal: Deal;
}

export default function DealAnalysis({ deal }: DealAnalysisProps) {
  const analysis = deal.analysis;
  
  if (!analysis) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-slate-500 text-center">No analysis data available for this deal.</p>
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (value: string | null) => {
    if (!value) return "N/A";
    const num = parseFloat(value);
    return `£${num.toLocaleString()}`;
  };

  const formatPercentage = (value: number | undefined) => {
    if (!value) return "N/A";
    return `${value.toFixed(2)}%`;
  };

  const getYieldColor = (yieldValue: number | undefined) => {
    if (!yieldValue) return "text-slate-500";
    if (yieldValue >= 8) return "text-green-600";
    if (yieldValue >= 6) return "text-yellow-600";
    return "text-red-600";
  };

  const getRoiColor = (roi: number | undefined) => {
    if (!roi) return "text-slate-500";
    if (roi >= 20) return "text-green-600";
    if (roi >= 15) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500 flex items-center">
              <Percent className="mr-1 h-4 w-4" />
              Gross Yield
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className={`text-2xl font-bold ${getYieldColor(analysis.grossYield)}`}>
              {formatPercentage(analysis.grossYield)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500 flex items-center">
              <TrendingUp className="mr-1 h-4 w-4" />
              Net Yield
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className={`text-2xl font-bold ${getYieldColor(analysis.netYield)}`}>
              {formatPercentage(analysis.netYield)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500 flex items-center">
              <Calculator className="mr-1 h-4 w-4" />
              ROI
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className={`text-2xl font-bold ${getRoiColor(analysis.roi)}`}>
              {formatPercentage(analysis.roi)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500 flex items-center">
              <PoundSterling className="mr-1 h-4 w-4" />
              Cash Flow
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-slate-900">
              {analysis.cashFlow ? `£${analysis.cashFlow.toLocaleString()}` : "N/A"}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Deal Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Deal Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-slate-900">Purchase Details</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-600">Purchase Price:</span>
                  <span className="font-medium">{formatCurrency(deal.price)}</span>
                </div>
                {deal.refurbCost && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">Refurb Cost:</span>
                    <span className="font-medium">{formatCurrency(deal.refurbCost)}</span>
                  </div>
                )}
                <div className="flex justify-between border-t pt-2">
                  <span className="text-slate-600 font-medium">Total Investment:</span>
                  <span className="font-bold">
                    {formatCurrency(String(parseFloat(deal.price) + parseFloat(deal.refurbCost || "0")))}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-slate-900">Rental Details</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-600">Monthly Rent:</span>
                  <span className="font-medium">{formatCurrency(deal.monthlyRent)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Annual Rent:</span>
                  <span className="font-medium">
                    {deal.monthlyRent ? formatCurrency(String(parseFloat(deal.monthlyRent) * 12)) : "N/A"}
                  </span>
                </div>
                {deal.marketValue && (
                  <div className="flex justify-between border-t pt-2">
                    <span className="text-slate-600 font-medium">Market Value:</span>
                    <span className="font-bold">{formatCurrency(deal.marketValue)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Indicators */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Assessment</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="font-medium">Yield Rating:</span>
              <Badge variant={analysis.grossYield && analysis.grossYield >= 8 ? "default" : analysis.grossYield && analysis.grossYield >= 6 ? "secondary" : "destructive"}>
                {analysis.grossYield && analysis.grossYield >= 8 ? "Excellent" : analysis.grossYield && analysis.grossYield >= 6 ? "Good" : "Below Average"}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="font-medium">ROI Rating:</span>
              <Badge variant={analysis.roi && analysis.roi >= 20 ? "default" : analysis.roi && analysis.roi >= 15 ? "secondary" : "destructive"}>
                {analysis.roi && analysis.roi >= 20 ? "Excellent" : analysis.roi && analysis.roi >= 15 ? "Good" : "Below Average"}
              </Badge>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h5 className="font-medium text-blue-900 mb-2">Investment Summary</h5>
              <p className="text-sm text-blue-800">
                This property offers a {formatPercentage(analysis.grossYield)} gross yield with an ROI of {formatPercentage(analysis.roi)}. 
                {analysis.grossYield && analysis.grossYield >= 8 
                  ? " This is considered an excellent yield for the current market."
                  : analysis.grossYield && analysis.grossYield >= 6
                  ? " This represents a solid yield opportunity."
                  : " The yield is below market average - consider your strategy carefully."
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
