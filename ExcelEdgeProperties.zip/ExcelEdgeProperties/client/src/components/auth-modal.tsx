import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { BarChart3, Building2 } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: "investor" | "sourcer";
}

export default function AuthModal({ isOpen, onClose, mode }: AuthModalProps) {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Join Excel Edge Properties</DialogTitle>
          <p className="text-center text-slate-600">Choose your account type to get started</p>
        </DialogHeader>

        <div className="space-y-4">
          <Button 
            className={`w-full p-4 h-auto justify-start ${mode === "investor" ? "bg-primary" : "bg-slate-100 text-slate-900 hover:bg-slate-200"}`}
            onClick={handleLogin}
          >
            <div className="flex items-center justify-between w-full">
              <div className="text-left">
                <div className="font-semibold">I'm an Investor</div>
                <div className={`text-sm ${mode === "investor" ? "text-blue-100" : "text-slate-500"}`}>
                  Browse deals and build your portfolio
                </div>
              </div>
              <BarChart3 className="h-5 w-5" />
            </div>
          </Button>
          
          <Button 
            variant={mode === "sourcer" ? "default" : "outline"}
            className={`w-full p-4 h-auto justify-start ${mode === "sourcer" ? "bg-primary" : ""}`}
            onClick={handleLogin}
          >
            <div className="flex items-center justify-between w-full">
              <div className="text-left">
                <div className="font-semibold">I'm a Property Sourcer</div>
                <div className={`text-sm ${mode === "sourcer" ? "text-blue-100" : "text-slate-500"}`}>
                  Submit deals and earn commissions
                </div>
              </div>
              <Building2 className="h-5 w-5" />
            </div>
          </Button>
        </div>

        <div className="mt-6 text-center">
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
