import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import AuthModal from "./auth-modal";
import { Building2, Menu, X, BarChart3, Home, Search, Plus, MessageSquare, Users, BookOpen, Settings } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<"investor" | "sourcer">("investor");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleGetStarted = (role: "investor" | "sourcer") => {
    setAuthMode(role);
    setShowAuthModal(true);
  };

  const isActive = (path: string) => location === path;

  return (
    <>
      <nav className="bg-white shadow-lg border-b border-blue-100 sticky top-0 z-50 backdrop-blur-sm bg-white/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-18">
            {/* Logo */}
            <Link href="/" className="flex items-center group transition-all duration-300 hover:scale-105">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-xl flex items-center justify-center mr-3 shadow-lg">
                <Building2 className="text-white h-6 w-6" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">Excel Edge Properties</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="flex items-baseline space-x-4">
                {isAuthenticated ? (
                  <>
                    <Link href="/" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      <Home className="inline mr-1 h-4 w-4" />
                      Dashboard
                    </Link>
                    <Link href="/deals" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/deals") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      <Search className="inline mr-1 h-4 w-4" />
                      Browse Deals
                    </Link>
                    {user?.role === "sourcer" && (
                      <Link href="/submit-deal" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/submit-deal") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                        <Plus className="inline mr-1 h-4 w-4" />
                        Submit Deal
                      </Link>
                    )}
                    <Link href="/blog" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/blog") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      <BookOpen className="inline mr-1 h-4 w-4" />
                      BRRR Hub
                    </Link>
                    <Link href="/partners" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/partners") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      <Users className="inline mr-1 h-4 w-4" />
                      Partners
                    </Link>
                    {user?.role === "admin" && (
                      <Link href="/admin" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/admin") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                        <Settings className="inline mr-1 h-4 w-4" />
                        Admin
                      </Link>
                    )}
                  </>
                ) : (
                  <>
                    <Link href="/deals" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/deals") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      Browse Deals
                    </Link>
                    <Link href="/blog" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/blog") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      BRRR Hub
                    </Link>
                    <Link href="/partners" className={`px-3 py-2 text-sm font-medium transition-colors ${isActive("/partners") ? "text-primary" : "text-slate-600 hover:text-primary"}`}>
                      Partners
                    </Link>
                  </>
                )}
              </div>
            </div>

            {/* Auth Buttons */}
            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <MessageSquare className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors cursor-pointer" />
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 text-xs p-0 flex items-center justify-center bg-primary text-white">
                      3
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg">
                      {user?.firstName?.[0] || '?'}
                    </div>
                    <span className="text-sm font-semibold text-foreground hidden sm:block">
                      {user?.firstName}
                    </span>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleLogout} className="border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300">
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="flex items-center space-x-3">
                  <Button variant="ghost" size="sm" onClick={handleLogin} className="text-primary hover:bg-blue-50 hover:text-primary font-semibold">
                    Login
                  </Button>
                  <Button size="sm" onClick={() => handleGetStarted("investor")} className="bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg transition-all duration-300 hover:shadow-xl rounded-lg px-6">
                    Get Started
                  </Button>
                </div>
              )}

              {/* Mobile menu button */}
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden border-t">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                {isAuthenticated ? (
                  <>
                    <Link href="/" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      Dashboard
                    </Link>
                    <Link href="/deals" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/deals") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      Browse Deals
                    </Link>
                    {user?.role === "sourcer" && (
                      <Link href="/submit-deal" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/submit-deal") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                        Submit Deal
                      </Link>
                    )}
                    <Link href="/blog" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/blog") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      BRRR Hub
                    </Link>
                    <Link href="/partners" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/partners") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      Partners
                    </Link>
                  </>
                ) : (
                  <>
                    <Link href="/deals" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/deals") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      Browse Deals
                    </Link>
                    <Link href="/blog" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/blog") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      BRRR Hub
                    </Link>
                    <Link href="/partners" className={`block px-3 py-2 text-base font-medium transition-colors ${isActive("/partners") ? "text-primary bg-blue-50" : "text-slate-600"}`}>
                      Partners
                    </Link>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </nav>

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
        mode={authMode}
      />
    </>
  );
}
