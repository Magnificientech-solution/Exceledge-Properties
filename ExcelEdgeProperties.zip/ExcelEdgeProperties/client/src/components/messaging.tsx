import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Send, MessageSquare, User } from "lucide-react";
import type { Message } from "@shared/schema";

interface MessagingProps {
  dealId?: string;
  otherUserId?: string;
}

export default function Messaging({ dealId, otherUserId }: MessagingProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [newMessage, setNewMessage] = useState("");
  const [subject, setSubject] = useState("");

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: otherUserId ? [`/api/conversations/${otherUserId}`, { dealId }] : ["/api/messages"],
    enabled: !!user,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { receiverId: string; dealId?: string; subject?: string; content: string }) => {
      return apiRequest("POST", "/api/messages", messageData);
    },
    onSuccess: () => {
      setNewMessage("");
      setSubject("");
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      if (otherUserId) {
        queryClient.invalidateQueries({ queryKey: [`/api/conversations/${otherUserId}`] });
      }
      toast({
        title: "Message sent",
        description: "Your message has been sent successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!newMessage.trim() || !otherUserId) return;

    sendMessageMutation.mutate({
      receiverId: otherUserId,
      dealId,
      subject: subject.trim() || undefined,
      content: newMessage.trim(),
    });
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-slate-500">Please log in to view messages.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Message List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageSquare className="mr-2 h-5 w-5" />
            {otherUserId ? "Conversation" : "Messages"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <p className="text-slate-500">No messages yet.</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`p-4 rounded-lg ${
                    message.senderId === user.id
                      ? "bg-primary text-white ml-8"
                      : "bg-slate-100 mr-8"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <User className="mr-2 h-4 w-4" />
                      <span className="text-sm font-medium">
                        {message.senderId === user.id ? "You" : "Other User"}
                      </span>
                    </div>
                    <span className={`text-xs ${message.senderId === user.id ? "text-blue-100" : "text-slate-500"}`}>
                      {new Date(message.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  {message.subject && (
                    <div className={`text-sm font-medium mb-2 ${message.senderId === user.id ? "text-blue-100" : "text-slate-700"}`}>
                      Subject: {message.subject}
                    </div>
                  )}
                  <p className={`text-sm ${message.senderId === user.id ? "text-white" : "text-slate-700"}`}>
                    {message.content}
                  </p>
                  {!message.isRead && message.receiverId === user.id && (
                    <Badge variant="secondary" className="mt-2">
                      Unread
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Send Message Form */}
      {otherUserId && (
        <Card>
          <CardHeader>
            <CardTitle>Send Message</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Subject (optional)"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
            <Textarea
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              rows={4}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || sendMessageMutation.isPending}
              className="w-full"
            >
              <Send className="mr-2 h-4 w-4" />
              Send Message
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
