import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertDealSchema, insertMessageSchema, insertPartnerSchema, insertTestimonialSchema, insertBlogPostSchema, insertDealInterestSchema } from "@shared/schema";
import { z } from "zod";

const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-05-28.basil",
}) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for Render.com monitoring
  app.get('/api/health', (req, res) => {
    res.status(200).json({ 
      status: 'healthy', 
      timestamp: new Date().toISOString(),
      service: 'excel-edge-properties-api'
    });
  });

  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Deal routes
  app.get('/api/deals', async (req, res) => {
    try {
      const { status, strategy, location } = req.query;
      const deals = await storage.getDeals({
        status: status as string,
        strategy: strategy as string,
        location: location as string,
      });
      res.json(deals);
    } catch (error) {
      console.error("Error fetching deals:", error);
      res.status(500).json({ message: "Failed to fetch deals" });
    }
  });

  app.get('/api/deals/:id', async (req, res) => {
    try {
      const deal = await storage.getDeal(req.params.id);
      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }
      res.json(deal);
    } catch (error) {
      console.error("Error fetching deal:", error);
      res.status(500).json({ message: "Failed to fetch deal" });
    }
  });

  app.post('/api/deals', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'sourcer' && user?.role !== 'admin') {
        return res.status(403).json({ message: "Only sourcers can create deals" });
      }

      const dealData = insertDealSchema.parse({
        ...req.body,
        sourcerId: userId,
      });

      // Calculate basic analysis
      const price = parseFloat(dealData.price);
      const monthlyRent = parseFloat(dealData.monthlyRent || '0');
      const refurbCost = parseFloat(dealData.refurbCost || '0');
      
      const analysis = {
        grossYield: monthlyRent > 0 ? (monthlyRent * 12 / price) * 100 : 0,
        netYield: monthlyRent > 0 ? ((monthlyRent * 12 - (price * 0.15)) / price) * 100 : 0, // Assuming 15% running costs
        roi: monthlyRent > 0 && refurbCost > 0 ? ((monthlyRent * 12) / (price + refurbCost)) * 100 : 0,
        cashFlow: monthlyRent * 12 - (price * 0.15), // Annual cash flow
      };

      const deal = await storage.createDeal({
        ...dealData,
        analysis,
      });

      res.json(deal);
    } catch (error) {
      console.error("Error creating deal:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create deal" });
      }
    }
  });

  app.put('/api/deals/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const deal = await storage.getDeal(req.params.id);

      if (!deal) {
        return res.status(404).json({ message: "Deal not found" });
      }

      if (deal.sourcerId !== userId && user?.role !== 'admin') {
        return res.status(403).json({ message: "Unauthorized to update this deal" });
      }

      const updates = insertDealSchema.partial().parse(req.body);
      const updatedDeal = await storage.updateDeal(req.params.id, updates);
      res.json(updatedDeal);
    } catch (error) {
      console.error("Error updating deal:", error);
      res.status(500).json({ message: "Failed to update deal" });
    }
  });

  // Get sourcer's deals
  app.get('/api/my-deals', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const deals = await storage.getSourcerDeals(userId);
      res.json(deals);
    } catch (error) {
      console.error("Error fetching sourcer deals:", error);
      res.status(500).json({ message: "Failed to fetch deals" });
    }
  });

  // Deal interest routes
  app.post('/api/deals/:id/interest', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (user?.role !== 'investor') {
        return res.status(403).json({ message: "Only investors can express interest" });
      }

      const interest = await storage.createDealInterest({
        dealId: req.params.id,
        investorId: userId,
        notes: req.body.notes,
      });

      res.json(interest);
    } catch (error) {
      console.error("Error creating deal interest:", error);
      res.status(500).json({ message: "Failed to express interest" });
    }
  });

  app.get('/api/deals/:id/interests', isAuthenticated, async (req, res) => {
    try {
      const interests = await storage.getDealInterests(req.params.id);
      res.json(interests);
    } catch (error) {
      console.error("Error fetching deal interests:", error);
      res.status(500).json({ message: "Failed to fetch interests" });
    }
  });

  // Message routes
  app.get('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getMessages(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.get('/api/conversations/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const otherUserId = req.params.userId;
      const dealId = req.query.dealId as string;
      
      const messages = await storage.getConversation(currentUserId, otherUserId, dealId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.post('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const senderId = req.user.claims.sub;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId,
      });

      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to send message" });
      }
    }
  });

  // Partner routes
  app.get('/api/partners', async (req, res) => {
    try {
      const { type } = req.query;
      const partners = await storage.getPartners(type as string);
      res.json(partners);
    } catch (error) {
      console.error("Error fetching partners:", error);
      res.status(500).json({ message: "Failed to fetch partners" });
    }
  });

  app.post('/api/partners', async (req, res) => {
    try {
      const partnerData = insertPartnerSchema.parse(req.body);
      const partner = await storage.createPartner(partnerData);
      res.json(partner);
    } catch (error) {
      console.error("Error creating partner:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create partner" });
      }
    }
  });

  // Testimonial routes
  app.get('/api/testimonials', async (req, res) => {
    try {
      const testimonials = await storage.getApprovedTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  app.post('/api/testimonials', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const testimonialData = insertTestimonialSchema.parse({
        ...req.body,
        userId,
      });

      const testimonial = await storage.createTestimonial(testimonialData);
      res.json(testimonial);
    } catch (error) {
      console.error("Error creating testimonial:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create testimonial" });
      }
    }
  });

  // Blog routes
  app.get('/api/blog', async (req, res) => {
    try {
      const posts = await storage.getPublishedBlogPosts();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  app.get('/api/blog/:slug', async (req, res) => {
    try {
      const post = await storage.getBlogPost(req.params.slug);
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  app.post('/api/blog', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Only admins can create blog posts" });
      }

      const postData = insertBlogPostSchema.parse({
        ...req.body,
        authorId: userId,
      });

      const post = await storage.createBlogPost(postData);
      res.json(post);
    } catch (error) {
      console.error("Error creating blog post:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create blog post" });
      }
    }
  });

  // Stripe payment routes
  if (stripe) {
    app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
      try {
        const { amount } = req.body;
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(amount * 100), // Convert to cents
          currency: "gbp",
        });
        res.json({ clientSecret: paymentIntent.client_secret });
      } catch (error: any) {
        res.status(500).json({ message: "Error creating payment intent: " + error.message });
      }
    });
  }

  const httpServer = createServer(app);
  return httpServer;
}
