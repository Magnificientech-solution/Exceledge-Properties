import {
  users,
  deals,
  messages,
  partners,
  testimonials,
  blogPosts,
  dealInterests,
  type User,
  type UpsertUser,
  type Deal,
  type InsertDeal,
  type Message,
  type InsertMessage,
  type Partner,
  type InsertPartner,
  type Testimonial,
  type InsertTestimonial,
  type BlogPost,
  type InsertBlogPost,
  type DealInterest,
  type InsertDealInterest,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, ilike, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeInfo: { customerId?: string; subscriptionId?: string }): Promise<User>;
  
  // Deal operations
  getDeals(filters?: { status?: string; strategy?: string; location?: string }): Promise<Deal[]>;
  getDeal(id: string): Promise<Deal | undefined>;
  createDeal(deal: InsertDeal): Promise<Deal>;
  updateDeal(id: string, updates: Partial<InsertDeal>): Promise<Deal>;
  getSourcerDeals(sourcerId: string): Promise<Deal[]>;
  getInvestorInterests(investorId: string): Promise<(DealInterest & { deal: Deal })[]>;
  
  // Message operations
  getMessages(userId: string): Promise<Message[]>;
  getConversation(user1Id: string, user2Id: string, dealId?: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(messageId: string): Promise<void>;
  
  // Partner operations
  getPartners(type?: string): Promise<Partner[]>;
  createPartner(partner: InsertPartner): Promise<Partner>;
  
  // Testimonial operations
  getApprovedTestimonials(): Promise<(Testimonial & { user: User })[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  
  // Blog operations
  getPublishedBlogPosts(): Promise<(BlogPost & { author: User })[]>;
  getBlogPost(slug: string): Promise<(BlogPost & { author: User }) | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  
  // Deal interest operations
  createDealInterest(interest: InsertDealInterest): Promise<DealInterest>;
  getDealInterests(dealId: string): Promise<(DealInterest & { investor: User })[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeInfo: { customerId?: string; subscriptionId?: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: stripeInfo.customerId,
        stripeSubscriptionId: stripeInfo.subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Deal operations
  async getDeals(filters?: { status?: string; strategy?: string; location?: string }): Promise<Deal[]> {
    let query = db.select().from(deals);
    
    const conditions = [];
    if (filters?.status) conditions.push(eq(deals.status, filters.status));
    if (filters?.strategy) conditions.push(eq(deals.strategy, filters.strategy));
    if (filters?.location) conditions.push(ilike(deals.location, `%${filters.location}%`));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return query.orderBy(desc(deals.createdAt));
  }

  async getDeal(id: string): Promise<Deal | undefined> {
    const [deal] = await db.select().from(deals).where(eq(deals.id, id));
    return deal;
  }

  async createDeal(deal: InsertDeal): Promise<Deal> {
    const [newDeal] = await db.insert(deals).values(deal).returning();
    return newDeal;
  }

  async updateDeal(id: string, updates: Partial<InsertDeal>): Promise<Deal> {
    const [deal] = await db
      .update(deals)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(deals.id, id))
      .returning();
    return deal;
  }

  async getSourcerDeals(sourcerId: string): Promise<Deal[]> {
    return db.select().from(deals).where(eq(deals.sourcerId, sourcerId)).orderBy(desc(deals.createdAt));
  }

  async getInvestorInterests(investorId: string): Promise<(DealInterest & { deal: Deal })[]> {
    return db
      .select()
      .from(dealInterests)
      .leftJoin(deals, eq(dealInterests.dealId, deals.id))
      .where(eq(dealInterests.investorId, investorId))
      .orderBy(desc(dealInterests.createdAt));
  }

  // Message operations
  async getMessages(userId: string): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(eq(messages.receiverId, userId))
      .orderBy(desc(messages.createdAt));
  }

  async getConversation(user1Id: string, user2Id: string, dealId?: string): Promise<Message[]> {
    const conditions = [
      and(eq(messages.senderId, user1Id), eq(messages.receiverId, user2Id)),
      and(eq(messages.senderId, user2Id), eq(messages.receiverId, user1Id))
    ];
    
    if (dealId) {
      conditions.push(eq(messages.dealId, dealId));
    }
    
    return db
      .select()
      .from(messages)
      .where(and(...conditions))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async markMessageAsRead(messageId: string): Promise<void> {
    await db.update(messages).set({ isRead: true }).where(eq(messages.id, messageId));
  }

  // Partner operations
  async getPartners(type?: string): Promise<Partner[]> {
    if (type) {
      return db.select().from(partners).where(eq(partners.type, type));
    }
    return db.select().from(partners);
  }

  async createPartner(partner: InsertPartner): Promise<Partner> {
    const [newPartner] = await db.insert(partners).values(partner).returning();
    return newPartner;
  }

  // Testimonial operations
  async getApprovedTestimonials(): Promise<(Testimonial & { user: User })[]> {
    return db
      .select()
      .from(testimonials)
      .leftJoin(users, eq(testimonials.userId, users.id))
      .where(eq(testimonials.approved, true))
      .orderBy(desc(testimonials.createdAt));
  }

  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const [newTestimonial] = await db.insert(testimonials).values(testimonial).returning();
    return newTestimonial;
  }

  // Blog operations
  async getPublishedBlogPosts(): Promise<(BlogPost & { author: User })[]> {
    return db
      .select()
      .from(blogPosts)
      .leftJoin(users, eq(blogPosts.authorId, users.id))
      .where(eq(blogPosts.published, true))
      .orderBy(desc(blogPosts.createdAt));
  }

  async getBlogPost(slug: string): Promise<(BlogPost & { author: User }) | undefined> {
    const [post] = await db
      .select()
      .from(blogPosts)
      .leftJoin(users, eq(blogPosts.authorId, users.id))
      .where(and(eq(blogPosts.slug, slug), eq(blogPosts.published, true)));
    return post;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [newPost] = await db.insert(blogPosts).values(post).returning();
    return newPost;
  }

  // Deal interest operations
  async createDealInterest(interest: InsertDealInterest): Promise<DealInterest> {
    const [newInterest] = await db.insert(dealInterests).values(interest).returning();
    return newInterest;
  }

  async getDealInterests(dealId: string): Promise<(DealInterest & { investor: User })[]> {
    return db
      .select()
      .from(dealInterests)
      .leftJoin(users, eq(dealInterests.investorId, users.id))
      .where(eq(dealInterests.dealId, dealId))
      .orderBy(desc(dealInterests.createdAt));
  }
}

export const storage = new DatabaseStorage();
