# Excel Edge Properties - Production Deployment Guide

## 🚀 Render.com Deployment Instructions

### Prerequisites
- GitHub repository with the Excel Edge Properties codebase
- Render.com account
- PostgreSQL database credentials

### Step 1: Database Setup on Render

1. **Create PostgreSQL Database**
   - Log into Render.com dashboard
   - Click "New +" → "PostgreSQL"
   - Database Name: `excel_edge_properties`
   - User: `excel_edge_user`
   - Region: Choose closest to your users
   - Plan: Free tier available

2. **Database Configuration**
   - Note the connection string (DATABASE_URL)
   - Database will auto-generate credentials

### Step 2: Backend API Deployment

1. **Create Web Service**
   - Click "New +" → "Web Service"
   - Connect GitHub repository
   - Branch: `main`
   - Runtime: Node.js

2. **Build Configuration**
   ```
   Build Command: npm install && npm run build
   Start Command: npm start
   ```

3. **Environment Variables**
   ```
   NODE_ENV=production
   PORT=10000
   DATABASE_URL=[Copy from PostgreSQL service]
   SESSION_SECRET=[Generate random 32-char string]
   ISSUER_URL=https://auth.replit.com/issuer
   REPLIT_DOMAINS=your-domain.replit.dev
   STRIPE_SECRET_KEY=sk_live_your_stripe_key
   FRONTEND_URL=https://excel-edge-properties-frontend.onrender.com
   ```

4. **Health Check**
   - Path: `/api/health`
   - Enable health check monitoring

### Step 3: Frontend Deployment

1. **Create Static Site**
   - Click "New +" → "Static Site"
   - Connect same GitHub repository
   - Branch: `main`

2. **Build Configuration**
   ```
   Build Command: npm install && npm run build
   Publish Directory: dist/public
   ```

3. **Environment Variables**
   ```
   VITE_API_URL=https://your-backend-service.onrender.com
   ```

### Step 4: Custom Domain (Optional)

1. **Backend Domain**
   - Go to backend service settings
   - Add custom domain: `api.excel-edge-properties.com`
   - Configure DNS CNAME record

2. **Frontend Domain**
   - Go to frontend service settings
   - Add custom domain: `excel-edge-properties.com`
   - Configure DNS CNAME record

### Step 5: Auto-Deploy Setup

1. **Enable Auto-Deploy**
   - Both services: Settings → Auto-Deploy
   - Enable "Auto-deploy from branch: main"

2. **GitHub Webhooks**
   - Automatically configured by Render
   - Push to main branch triggers deployment

## 📋 Environment Variables Reference

### Backend (.env)
```bash
# Required
NODE_ENV=production
PORT=10000
DATABASE_URL=postgresql://user:pass@host:port/dbname

# Authentication
SESSION_SECRET=your-32-character-random-string
ISSUER_URL=https://auth.replit.com/issuer
REPLIT_DOMAINS=your-domain.replit.dev

# Optional
STRIPE_SECRET_KEY=sk_live_your_stripe_key
FRONTEND_URL=https://your-frontend-url.onrender.com
```

### Frontend (.env.production)
```bash
VITE_API_URL=https://your-backend-url.onrender.com
```

## 🔧 Production Optimizations

### Backend Optimizations
- Health check endpoint at `/api/health`
- CORS configured for production domains
- Express session management
- Error handling and logging

### Frontend Optimizations
- Vite production build optimization
- Static asset caching
- Royal blue theme CSS variables
- Mobile-responsive design

## 🛠️ Troubleshooting

### Common Issues

1. **CORS Errors**
   - Verify FRONTEND_URL in backend environment
   - Check domain spelling in CORS configuration

2. **Database Connection**
   - Verify DATABASE_URL format
   - Check PostgreSQL service status

3. **Build Failures**
   - Check Node.js version compatibility
   - Verify all dependencies in package.json

4. **Authentication Issues**
   - Verify Replit Auth configuration
   - Check ISSUER_URL and REPLIT_DOMAINS

### Health Checks
- Backend: `https://your-api.onrender.com/api/health`
- Should return: `{"status":"healthy","timestamp":"...","service":"excel-edge-properties-api"}`

## 📊 Monitoring

### Render Dashboard
- Service logs and metrics
- Performance monitoring
- Uptime tracking
- Resource usage

### Database Monitoring
- Connection count
- Query performance
- Storage usage

## 🔄 Updates and Maintenance

### Deployment Process
1. Push changes to main branch
2. Auto-deploy triggers build
3. Zero-downtime deployment
4. Health check verification

### Database Migrations
```bash
npm run db:push
```

## 🎯 Production URLs

- **Frontend**: https://excel-edge-properties-frontend.onrender.com
- **Backend API**: https://excel-edge-properties-api.onrender.com
- **Health Check**: https://excel-edge-properties-api.onrender.com/api/health

---

*This guide ensures professional deployment of Excel Edge Properties on Render.com with proper monitoring and maintenance procedures.*