# Excel Edge Properties - Replit Development Guide

## Overview

Excel Edge Properties is a full-stack property investment platform that connects property sourcers with investors across the UK and Nigeria. The application facilitates property deal discovery, analysis, and investment management with integrated payment processing and comprehensive user management.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state and caching
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Authentication**: Replit Auth with OpenID Connect integration
- **Session Management**: PostgreSQL-backed sessions using connect-pg-simple
- **API Design**: RESTful endpoints with consistent error handling
- **File Structure**: Monorepo structure with shared types between client and server

### Database Architecture
- **Database**: PostgreSQL (Neon serverless)
- **ORM**: Drizzle ORM with TypeScript schema definitions
- **Migrations**: Drizzle Kit for database migrations
- **Schema Location**: `shared/schema.ts` for type sharing across client/server

## Key Components

### User Management
- Multi-role system: investors, sourcers, and administrators
- Replit Auth integration for secure authentication
- User preferences and profile management
- Stripe customer integration for payment processing

### Property Deal Management
- Deal submission and approval workflow
- Comprehensive property analysis with financial metrics
- Image upload and property documentation
- Status tracking (pending, approved, rejected)
- Deal filtering and search functionality

### Financial Analysis Engine
- Automated calculation of investment metrics:
  - Gross and net rental yields
  - Return on investment (ROI)
  - Cash flow analysis
  - Buy-Refurb-Rent-Refinance (BRRR) calculations
- Currency support for GBP and NGN markets

### Messaging System
- Deal-specific communication between investors and sourcers
- Message threading and conversation management
- Real-time notifications and status updates

### Content Management
- Blog post system for educational content
- Partner directory management
- Testimonial collection and display
- User-generated content moderation

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth → server validates → session stored in PostgreSQL
2. **Deal Submission**: Sourcers submit deals → admin approval → published to marketplace
3. **Investment Interest**: Investors express interest → notification to sourcer → deal negotiation
4. **Payment Processing**: Stripe integration for fees, deposits, and subscriptions
5. **Analysis Pipeline**: Deal data → financial calculations → cached results → client display

## External Dependencies

### Core Dependencies
- **Database**: PostgreSQL via Neon serverless platform
- **Authentication**: Replit Auth service
- **Payments**: Stripe for financial transactions
- **File Storage**: Planned integration for property images
- **Email**: Planned integration for notifications

### Development Dependencies
- **TypeScript**: Full type safety across stack
- **ESBuild**: Server-side bundling for production
- **PostCSS**: CSS processing pipeline
- **Zod**: Runtime type validation and schema generation

## Deployment Strategy

### Development Environment
- **Runtime**: Replit environment with Node.js 20
- **Database**: Automatic PostgreSQL provisioning
- **Hot Reload**: Vite HMR for frontend, tsx watch for backend
- **Port Configuration**: Frontend on 5000, proxied to external port 80

### Production Build
- **Frontend**: Vite production build to `dist/public`
- **Backend**: ESBuild bundle to `dist/index.js`
- **Deployment**: Replit autoscale deployment target
- **Environment**: Production NODE_ENV with optimized builds

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `REPLIT_DOMAINS`: Allowed domains for auth
- `SESSION_SECRET`: Session encryption key
- `STRIPE_SECRET_KEY`: Stripe API key for payments
- `ISSUER_URL`: OpenID Connect issuer URL

## Recent Changes

- June 18, 2025: Complete royal blue theme implementation across all components
- June 18, 2025: Fixed SelectItem runtime error preventing deal browsing functionality  
- June 18, 2025: Added dialog accessibility compliance with aria-describedby attributes
- June 18, 2025: Comprehensive testing completed - all functionality verified operational
- June 18, 2025: Test certificates issued for Unit, UAT, Regression, API, and Performance testing

## Changelog

- June 18, 2025: Initial setup with full-stack architecture
- June 18, 2025: Royal blue design system implementation
- June 18, 2025: Complete testing phase with production-ready certification

## User Preferences

Preferred communication style: Simple, everyday language.