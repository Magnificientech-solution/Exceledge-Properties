# Manual Git Commands for GitHub Deployment

## Step 1: Download Project Files
Download all project files from Replit to your local machine or use the following commands if you have terminal access:

## Step 2: Initialize and Push to GitHub

### Option A: If starting fresh locally
```bash
# Navigate to your project directory
cd excel-edge-properties

# Initialize git repository
git init

# Add all files
git add .

# Make initial commit
git commit -m "Initial commit: Excel Edge Properties production-ready app"

# Add GitHub remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/excel-edge-properties.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Option B: If git is already initialized
```bash
# Check current status
git status

# Add any untracked files
git add .

# Commit changes
git commit -m "Production-ready Excel Edge Properties app"

# Add GitHub remote if not exists (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/excel-edge-properties.git

# Push to GitHub
git push -u origin main
```

## Step 3: Verify GitHub Repository
1. Go to https://github.com/YOUR_USERNAME/excel-edge-properties
2. Verify all files are present:
   - client/ folder
   - server/ folder
   - shared/ folder
   - package.json
   - README.md
   - .env.example
   - All other production files

## Ready for Render Deployment
Once pushed to GitHub, follow the Render deployment steps in GITHUB_DEPLOY_GUIDE.md